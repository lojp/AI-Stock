
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""

import easytrader
user = easytrader.use('gj_client') 
user.prepare(user='40584845', password='000530')
user.balance