# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
""" 
import pandas as pd
import tushare as ts
import os
import numpy as np
import operator
import time
from datetime import datetime
from tabulate import tabulate


proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

# def showchange(code):
    # df = ts.get_realtime_quotes(['sh','sz','cyb','002503','600463','300042',code])
    # # matrix =np.array(df[['code','name','price','pre_close','high','low','time']])
    # matrix =np.array(df[['code','price','pre_close','high','low','time']])
    # my_columns = ['code','price','change','pre_close','high','low','time']
    # a = list(map(float, matrix[:, 1]))
    # b = list(map(float, matrix[:, 2]))
    # c = list([str(round((x/y-1)*100,2))+'%' for x,y in zip(a, b)])
    # d = np.insert(matrix, 2,c, axis=1)
    # newdf = pd.DataFrame(d)
    # newdf.columns = my_columns
    # return (newdf)

# def timeshow(n,code):
    # while True:
        # showchange(code)
        # time.sleep(n)

# def main(n,code):
    # # print('行情监控'.center(36,'-'))
    # while True:
        # # '''主函数入口'''
        # info = showchange(code)
        # print(tabulate(info, headers='keys', tablefmt='psql',numalign="center"))  #orgtbl,psql
        # # print('END'.center(42,'-'))
        # time.sleep(n)

# if __name__ == '__main__':
    # main(31,'600898')
    
    
def append_df_to_excel(df, excel_path):
    df_excel = pd.read_excel(excel_path)
    result = pd.concat([df_excel, df], ignore_index=True)
    result.to_excel(excel_path, index=False)

mydir = 'C:/Users/jluo27/Desktop/'
ts_token='0c98ac2886e4331d7120a91573d3d025ba2eec7c96bfac77f9b7153d'
ts.set_token(ts_token)
pro = ts.pro_api()
code = '300637.SZ,603035.SH,300456.SZ,600460.SH,002662.SZ,600487.SH,601021.SH,601958.SH,300339.SZ,300268.SZ,300031.SZ,000721.SZ,300033.SZ,300601.SZ,600081.SH,002741.SZ,300429.SZ,601788.SH,300409.SZ,'
df = pro.daily(ts_code=code, start_date='20200828')
writer = pd.ExcelWriter(mydir + 'weeklyreview.xls', engine='xlsxwriter')
df.to_excel(writer, sheet_name='Table',index=False,encoding='utf-8')		    
writer.save()
