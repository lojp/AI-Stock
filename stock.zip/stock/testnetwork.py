import socket
import socks
import os
from pytdx.hq import TdxHq_API
socks.set_default_proxy(socks.PROXY_TYPE_SOCKS5, "fmcpr002-p1.nb.ford.com", 83)
socket.socket = socks.socksocket
# proxy = 'fmcpr002-p1.nb.ford.com:83'
# os.environ['http_proxy'] = proxy 
# os.environ['HTTP_PROXY'] = proxy
# os.environ['https_proxy'] = proxy
# os.environ['HTTPS_PROXY'] = proxy
# myproxy='117.34.114.31'
# #pytdx服务器端口
# myport=7709
# # socket.create_connection((myproxy, myport), proxy_type='PROXY_TYPE_SOCKS5', proxy_addr='fmcpr002-p1.nb.ford.com',proxy_port=83)
# socket.create_connection((myproxy, myport),5)
# print('ok')
api = TdxHq_API()
with api.connect('117.34.114.31', 7709):
    data = api.get_security_bars(9, 0, '000001', 0, 10) #返回普通list
    print(data)