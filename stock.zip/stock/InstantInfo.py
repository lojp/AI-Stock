# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
"""
import tushare as ts
import os
import numpy as np
import operator
import pandas as pd

proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

#df = ts.get_realtime_quotes('000931') #Single stock symbol
df = ts.get_realtime_quotes(['sh','sz','cyb','000931'])
matrix =np.array(df[['code','price','pre_close','high','low','time']])
#print(matrix)
a = list(map(float, matrix[:, 1]))
b = list(map(float, matrix[:, 2]))
#c = list(map(operator.truediv,a,b))

c = list([str(round((x/y-1)*100,2))+'%' for x,y in zip(a, b)])
d = np.insert(matrix, 1,c, axis=1)
newdf = pd.DataFrame(d)
my_columns = ['code','change','price','pre_close','high','low','time']
newdf.columns = my_columns
print(newdf)

#df = ts.get_hist_data('000931', start = '2017-05-18', end = '2017-05-19')
#print(df)