# -*- coding: utf-8 -*-
"""
Created on Jun 21 09:37:17 2017

@author: jluo27
"""
import pandas as pd

df = pd.read_pickle('C:/Private/Analysis/python/mine/stock/result.pkl')

print(df)