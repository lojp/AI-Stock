#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 18 10:43:00 2018

@author: luogan
"""

import tushare as ts
import datetime
import pandas as pd
import pymongo


ak=ts.get_stock_basics()

code=list(ak.index)

def front_step_time(day):
    now = datetime.datetime.now()
    front = now - datetime.timedelta(days=day)
    d1 = front.strftime('%Y-%m-%d')
    #return int(d1)
    return d1

now=front_step_time(0)

bf=front_step_time(10)

sheet=pd.DataFrame()
sheet['code']=code

sheet['bf']=bf
sheet['sta']=now
#name='600354'
#b1=potential_vocanol(name,'2017-11-14','2018-02-14')
#b2=potential_vocanol(name,'2018-02-14','2018-04-13')
client1 = pymongo.MongoClient('192.168.10.182',27017)
db1 = client1.stock.turnover1

def potential_vocanol(tl):
    #name='600354'
    df=ts.get_hist_data(tl[0],start=tl[1],end=tl[2])
    print(type(df))
    if str(type(df))=="<class 'pandas.core.frame.DataFrame'>":
        print(df)
        a=df['turnover'].sum()
        print(tl[0],int(a))
        db1.save({'name':tl[0],'turnover':a})
    #return int(a)


'''
for i in sheet.values:
    b1=potential_vocanol(i)
'''




import time
from multiprocessing import Pool
import numpy as np



def run(fn) :#将函数的输入换成列表或元组，即将多元输入打包
  a=fn[0]*fn[1]
  print (a)


if __name__ == "__main__" :
  startTime = time.time()
  testFL =sheet.values
  #ll=code
  pool = Pool(10)#可以同时跑10个进程
  pool.map(potential_vocanol,testFL)
  pool.close()
  pool.join()   
  endTime = time.time()
  print ("time :", endTime - startTime)
