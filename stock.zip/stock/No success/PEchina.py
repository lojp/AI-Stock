# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
@author: jluo27
"""
import baostock as bs
import pandas as pd
import os

proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

# #### 登陆系统 ####
# lg = bs.login(user_id="anonymous", password="123456")
# #### 获取沪深A股估值指标(日频)数据 ####
# # peTTM    动态市盈率
# # psTTM    市销率
# # pcfNcfTTM    市现率
# # pbMRQ    市净率
# rs = bs.query_history_k_data("sh.600000",
    # "date,code,close,peTTM,pbMRQ,psTTM,pcfNcfTTM",
    # start_date='2015-01-01', end_date='2017-12-31', 
    # frequency="d", adjustflag="3")
# #### 打印结果集 ####
# result_list = []
# while (rs.error_code == '0') & rs.next():
    # # 获取一条记录，将记录合并在一起
    # result_list.append(rs.get_row_data())
# result = pd.DataFrame(result_list, columns=rs.fields)

# #### 结果集输出到csv文件 ####
# result.to_csv("C:/Private/Analysis/python/mine/stock/peTTM_sh.600000_data.csv", encoding="gbk", index=False)
# print(result)

# #### 登出系统 ####
# bs.logout()


lg = bs.login(user_id="anonymous", password="123456")
# 显示登陆返回信息
print(lg.error_code)
print(lg.error_msg)
# 详细指标参数，参见“历史行情指标参数”章节
rs = bs.query_history_k_data("sh.601398",
    "date,code,open,high,low,close,volume,amount,adjustflag",
    start_date='2017-01-01', end_date='2017-01-31',
    frequency="d", adjustflag="3")
print(rs.error_code)
print(rs.error_msg)
# 获取具体的信息
result = pd.DataFrame(columns=["date","code","open","high","low","close","volume","amount","adjustflag"])
while (rs.error_code == '0') & rs.next():
    # 分页查询，将每页信息合并在一起
    result = result.append(rs.get_row_data(), ignore_index=True)
result.to_csv("D:\history_k_data.csv", index=False)
print(result)
# 登出系统
bs.logout()