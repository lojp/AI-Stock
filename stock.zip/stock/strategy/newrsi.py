import talib

def init(context):
    # 选择沪深300成分股作为股票池
    context.stocks=index_components("000300.XSHG")
    # 设置RSI天数
    context.HS300_TIME_PERIOD =20 
    context.STOCK_TIME_PERIOD =10
    # 设置股票超买超卖线
    context.STOCK_HIGH_RSI = 80
    context.STOCK_LOW_RSI = 10
    # 设置指数超买超卖线
    context.HS300_HIGH_RSI = 90
    context.HS300_LOW_RSI = 10
    # 设置单只股票持仓量
    context.ORDER_PERCENT =0.01
    
def handle_bar(context, bar_dict):
    # 求沪深300RSI值
    HS300_prices=history_bars('000300.XSHG',context.HS300_TIME_PERIOD+1, '1d', 'close')
    HS300_rsi_data = talib.RSI(HS300_prices, timeperiod=context.HS300_TIME_PERIOD)[-1]
    for stock in context.stocks:
        # 读取历史数据
        stock_prices = history_bars(stock,context.STOCK_TIME_PERIOD+1, '1d', 'close')
        # 用Talib计算RSI值
        stock_rsi_data = talib.RSI(stock_prices, timeperiod=context.STOCK_TIME_PERIOD)[-1]
        stock_cur_position=context.portfolio.positions[stock].quantity
        # 当沪深300的RSI大于超买线或在超卖线和中线之间，完全空仓
        if  HS300_rsi_data>context.HS300_HIGH_RSI or context.HS300_LOW_RSI<HS300_rsi_data<50:
            order_target_value(stock, 0)
        # 当股票的RSI大于超买线或在超卖线和中线之间，清仓
        elif (stock_rsi_data > context.STOCK_HIGH_RSI or 45<stock_rsi_data<50) and stock_cur_position > 0:
            order_target_value(stock, 0)
        # 当股票的RSI小于超卖线或在超买线和中线之间，购买股票至设定持仓量
        elif stock_cur_position==0 and (stock_rsi_data>50 or stock_rsi_data<context.STOCK_LOW_RSI):
            order_percent(stock,context.ORDER_PERCENT)