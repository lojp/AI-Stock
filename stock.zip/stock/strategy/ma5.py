import talib

# 初始化函数
def init(context):
    context.s1 = "000001.XSHE"
    

def handle_bar(context, bar_dict):
    prices = history_bars(context.s1, 10, '1d', 'close')

    
    ma5 = talib.SMA(prices, 5)[-1]
    ma10 = talib.SMA(prices, 10)[-1]

    if ma5 < ma10:
        # 满仓入股
        order_target_percent(context.s1, 1)

    elif ma5 > ma10:
        # 获取该股票的仓位
        curPosition = context.portfolio.positions[context.s1].quantity
        # 清仓
        if curPosition > 0:
            order_target_value(context.s1, 0)