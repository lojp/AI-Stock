import os
import pandas as pd
import numpy as np
from datetime import datetime,timedelta
import talib
import math
import cmath
import random as ran

# init方法是您的初始化逻辑。context对象可以在任何方法之间传递。
def init(context):
    #标准参考
    #context.benchmark="000001.XSHE"#参考对象
    #context.slippage=0.003#滑点
    #context.commission=0.02#交易佣金
    #指数标准池
    #context.s1 = '000985.SH'  #中证全指   剔除掉ST*ST暂停上市股票以及上市时间不足3个月
#    context.s2 = '000016.SH'  #上证50指数 规模大、流动性好
#    context.s3 = '399333.SZ'  #中小板R    中小板创业板代表性较强流动性较好100
#    context.s4 = '000905.SH'  #中证500    剔除:沪深300日均成额排后20%.日均总市值前500
#    context.s5 = '000009.SH'  #上证380    380家规模适中、成长性好、盈利能力强
#    context.s6 = '000010.SH'  #上证180    总市值、流通市值、成交金额和换手率综合排名靠前
    #买入仓池    context.buyListone = []#大股票池三个
    context.buyListtwo = []
    context.buyListthree = []
    context.buyList1 = []#买入仓位信息
    context.buyList2 = []
    context.buyList3 = []
    context.buyList4 = []
    context.buyList5 = []
    context.buyList6 = []#六个list从大List中取
    #持仓数量限制
    context.holdSize1 = 10
    context.holdSize2 = 14
    context.holdSize3 = 20
    context.holdSize4 = 20
    context.holdSize5 = 20
    context.holdSize6 = 15
    #止盈止损
    context.win1 = 0.03
    context.win2 = 0.05
    context.win3 = 0.05
    context.win4 = 0.03
    context.win5 = 0.03
    context.win6 = 0.05
    context.lose1 = -0.99
    context.lose2 = -0.99
    context.lose3 = -0.99
    context.lose4 = -0.99
    context.lose5 = -0.99
    context.lose6 = -0.99
    #Macd参数设置
    context.SHORTPERIOD = 12
    context.LONGPERIOD = 26
    context.SMOOTHPERIOD = 9
    context.OBSERVATION = 100
    #股票个性化参数设置
    context.stkcan1 = {}
    context.stkcan2 = {}
    context.stkcan3 = {}
    context.stkcan4 = {}
    context.stkcan5 = {}
    context.stkcan6 = {}
    context.panret = 0
    context.ret = 0


def popst(stkList,bar_dict):
    #过滤st和停牌
    stkList = [stk for stk in stkList if not is_st_stock(stk) and not is_suspended(stk)]
    return stkList
def popzdt(stk,bar_dict,context):
    #过滤涨跌停
    yesterday = history(2,'1d', 'close')[stk].values[-1]
    zt = round(1.0985 * yesterday,4)
    dt = round(0.9025 * yesterday,4)
    if dt <= bar_dict[stk].last <= zt :
        return True
    else : 
        return False
#知飞科技原创 · 新元blank
def shangyingxian(stk,bar_dict,context):
    #过滤上影线过长
    global ret
    high = bar_dict[stk].high
    kai = bar_dict[stk].open
    close = bar_dict[stk].close
    if kai > close:
        context.ret=(high-kai)/high
    elif kai < close:
        context.ret=(high-close)/high
    if context.ret < 0.015:
        return True
    else : 
        return False
def Select(context,bar_dict,stkList):
    buyList = []
    buyList = popst(stkList,bar_dict)                                         #st停牌
    buyList = [stk for stk in buyList if 4<bar_dict[stk].close<50]            #4-50元之间
    buyList = [stk for stk in buyList if popzdt(stk,bar_dict, context)]       #涨跌停
    buyList = [stk for stk in buyList if shangyingxian(stk,bar_dict, context)]#上影线太长不买
    return buyList
def Select1(context,bar_dict,stkList):
    #低于MA5 * 0.90
    buyList0 = []
    for stk in stkList:
        close1 = round(bar_dict[stk].close,2)
        his1 = history(4,'1d','close')[stk].values
        avg1 = 0
        for i in range(4):
            avg1 += his1[i]
        avg11 = round(((avg1 + close1) / 5),2)
        if close1 < avg11 * 0.9:
            buyList0.append(stk)
    return buyList0
def Select2(context,bar_dict,stkList):
    #Macd连跌
    buyList0 = []
    for stk in stkList:
        prices = history(context.OBSERVATION,'1d','close')[stk].values
        macd, signal, hist = talib.MACD(prices, context.SHORTPERIOD,context.LONGPERIOD, context.SMOOTHPERIOD)
        if macd[-1] - signal[-1] > 0 and macd[-2] - signal[-2] < 0:
             buyList0.append(stk)
    return buyList0
#知飞科技原创 · 新元blank
def Select3(context,bar_dict,stkList):
    #HMM第一版初级参数策略
    buyList0 = []
    for stk in stkList:
        close3 = bar_dict[stk].last
        his3 = history(60,'1d','close')[stk].values
        kai3 = history(60,'1d','open')[stk].values
        his33 = np.array(his3)
        avg3 = 0
        avg33 = 0
        for i in range(60):
            avg3 += his3[i]
            avg33 += kai3[i]
        avg31 = (avg3+avg33) / 120
        high3 = history(20,'1d','high')[stk].values.max()
        low3 = history(20,'1d','low')[stk].values.min()
        random3 = ran.random()
        bodong31 = math.log(close3/high3)
        bodong32 = math.log(close3/low3)
        bodong3 = (bodong31 + bodong32) / 2
        if close3 > (avg31 + bodong3*0.8*random3) :
            buyList0.append(stk)
    return buyList0
#知飞科技原创 · 新元blank
def Select4(context,bar_dict,stkList):
    #初级波动率
    buyList0 = []
    for stk in stkList:
        high=history(238,'1m','high')[stk].values.max()
        his = history(2, '1d', 'close')[stk].values
        bodong = (high / his[1]) - 1
        if bodong > 0.04:
            buyList0.append(stk)
    return buyList0
def Select5(context,bar_dict,stkList):
    #低开
    buyList0 = []
    for stk in stkList:
        close5 = bar_dict[stk].last
        his5 = history(2,'1d','close')[stk].values
        kai5 = bar_dict[stk].open
        high5 = bar_dict[stk].high
        if close5 < his5[1] and high5 < his5[1] and kai5 < his5[1]:
            buyList0.append(stk)
    return buyList0
def Select6(context,bar_dict,stkList):
    #广发证券量化分析团队修正TD指标的指数择时初级版
    buyList0 = []
    for stk in stkList:
        close6 = bar_dict[stk].last
        his6 = history(12,'1d','close')[stk].values
        if close6<his6[8] and his6[11]<his6[7] and his6[10]<his6[6] and his6[9]<his6[5] and his6[8]<his6[4] and his6[7]<his6[3] and his6[6]<his6[2] and his6[5]<his6[1] and his6[4]<his6[0]:
            buyList0.append(stk)
    return buyList0
#知飞科技原创 · 新元blank
# 日或分钟或实时数据更新，将会调用这个方法
def handle_bar(context, bar_dict):
    #时间
    now = context.now
    #止盈止损
    if not (now.hour == 14 and now.minute >= 59) and now.hour != 15:
        popList1 = []
        popList2 = []
        popList3 = []
        popList4 = []
        popList5 = []
        popList6 = []
        for stk in context.stkcan1.keys():
            if stk in context.portfolio.positions.keys():
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 >= context.win1:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止盈1',stk)
                            popList1.append(stk)
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 <= context.lose1:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止损1',stk)
                            popList1.append(stk)
        for stk in context.stkcan2.keys():
            if stk in context.portfolio.positions.keys():
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 >= context.win2:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止盈2',stk)
                            popList2.append(stk)
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 <= context.lose2:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止损2',stk)
                            popList2.append(stk)
        for stk in context.stkcan3.keys():
            if stk in context.portfolio.positions.keys():
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 >= context.win3:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止盈3',stk)
                            popList3.append(stk)
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 <= context.lose3:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止损3',stk)
                            popList3.append(stk)
        for stk in context.stkcan4.keys():
            if stk in context.portfolio.positions.keys():
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 >= context.win4:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止盈4',stk)
                            popList4.append(stk)
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 <= context.lose4:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止损4',stk)
                            popList4.append(stk)
        for stk in context.stkcan5.keys():
            if stk in context.portfolio.positions.keys():
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 >= context.win5:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止盈5',stk)
                            popList5.append(stk)
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 <= context.lose5:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止损5',stk)
                            popList5.append(stk)
        for stk in context.stkcan6.keys():
            if stk in context.portfolio.positions.keys():
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 >= context.win6:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止盈6',stk)
                            popList6.append(stk)
                if context.portfolio.positions[stk].quantity != 0:
                    if (context.portfolio.positions[stk].avg_price) != 0:
                        if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 <= context.lose6:
                        #如果 当前价和成本价的差价大于预定值 则卖出
                            order_target_value(stk, 0)
                            print('止损6',stk)
                            popList6.append(stk)
        for stk in popList1:
            if stk in context.stkcan1.keys():
                context.stkcan1.pop(stk)
        for stk in popList2:
            if stk in context.stkcan2.keys():
                context.stkcan2.pop(stk)
        for stk in popList3:
            if stk in context.stkcan3.keys():
                context.stkcan3.pop(stk)
        for stk in popList4:
            if stk in context.stkcan4.keys():
                context.stkcan4.pop(stk)
        for stk in popList5:
            if stk in context.stkcan5.keys():
                context.stkcan5.pop(stk)
        for stk in popList6:
            if stk in context.stkcan6.keys():
                context.stkcan6.pop(stk)
    #加仓 超出持仓日期卖出
    if now.hour==14 and now.minute == 57:
        popList = []
        for stk in context.stkcan1.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan1[stk]['holddays'] < 5:
                    if context.stkcan1[stk]['times'] < 5:
                        order_lots(stk,context.stkcan1[stk]['holddays']+(6 - context.stkcan1[stk]['times']))
                        context.stkcan1[stk]['times'] += 1#初级版本设定为1的增量
        for stk in context.stkcan2.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan2[stk]['holddays'] < 5:
                    if context.stkcan2[stk]['times'] < 5:
                        order_lots(stk,context.stkcan2[stk]['holddays']+context.stkcan2[stk]['times']+1)
                        context.stkcan2[stk]['times'] += 1
        for stk in context.stkcan3.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan3[stk]['holddays'] < 5:
                    if 1<context.stkcan3[stk]['times'] < 3:
                        order_lots(stk,context.stkcan3[stk]['times']*(6-context.stkcan3[stk]['holddays']))
                        context.stkcan3[stk]['times'] += 1
        for stk in context.stkcan4.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan4[stk]['holddays'] < 5:
                    if context.stkcan4[stk]['times'] < 3:
                        order_lots(stk,context.stkcan4[stk]['holddays']*(6-context.stkcan4[stk]['times']))
                        context.stkcan4[stk]['times'] += 1
        for stk in context.stkcan5.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan5[stk]['holddays'] < 5:
                    if context.stkcan5[stk]['times'] < 5:
                        order_lots(stk,context.stkcan5[stk]['holddays'] + (6-context.stkcan5[stk]['times']))
                        context.stkcan5[stk]['times'] += 1
        for stk in context.stkcan6.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan6[stk]['holddays'] < 5:
                    if context.stkcan6[stk]['times'] < 4:
                        order_lots(stk,context.stkcan6[stk]['holddays'] + (6 - context.stkcan6[stk]['times'])*2)
                        context.stkcan6[stk]['times'] += 1
            #初级版本暂时不按照每个策略收益动态调整仓位投入额度
        for stk in context.stkcan1.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan1[stk]['holddays'] >= 5 and context.stkcan1[stk]['holddays'] % 4 == 0:
                    order_lots(stk,3)
        for stk in context.stkcan2.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan2[stk]['holddays'] >= 5 and context.stkcan2[stk]['holddays'] % 4 == 0:
                    order_lots(stk,2)
        for stk in context.stkcan3.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan3[stk]['holddays'] >= 5 and context.stkcan3[stk]['holddays'] % 4 == 0:
                    order_lots(stk,4)
        for stk in context.stkcan4.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan4[stk]['holddays'] >= 5 and context.stkcan4[stk]['holddays'] % 4 == 0:
                    order_lots(stk,3)
        for stk in context.stkcan5.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan5[stk]['holddays'] >= 5 and context.stkcan5[stk]['holddays'] % 4 == 0:
                    order_lots(stk,2)
        for stk in context.stkcan6.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan6[stk]['holddays'] >= 5 and context.stkcan6[stk]['holddays'] % 4 == 0:
                    order_lots(stk,3)
        for stk in context.stkcan1.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan1[stk]['holddays'] >= 40:
                    order_target_value(stk, 0)
                    print('持仓时间超出1',stk)
                    popList.append(stk)
        for stk in context.stkcan2.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan2[stk]['holddays'] >= 40:
                    order_target_value(stk, 0)
                    print('持仓时间超出2',stk)
                    popList.append(stk)
        for stk in context.stkcan3.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan3[stk]['holddays'] >= 40:
                    order_target_value(stk, 0)
                    print('持仓时间超出3',stk)
                    popList.append(stk)
        for stk in context.stkcan4.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan4[stk]['holddays'] >= 40:
                    order_target_value(stk, 0)
                    print('持仓时间超出4',stk)
                    popList.append(stk)
        for stk in context.stkcan5.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan5[stk]['holddays'] >= 40:
                    order_target_value(stk, 0)
                    print('持仓时间超出5',stk)
                    popList.append(stk)
        for stk in context.stkcan6.keys():
            if stk in context.portfolio.positions.keys():
                if context.stkcan6[stk]['holddays'] >= 40:
                    order_target_value(stk, 0)
                    print('持仓时间超出6',stk)
                    popList.append(stk)
        for stk in popList:
            if stk in context.stkcan1.keys():
                context.stkcan1.pop(stk)
            if stk in context.stkcan2.keys():
                context.stkcan2.pop(stk)
            if stk in context.stkcan3.keys():
                context.stkcan3.pop(stk)
            if stk in context.stkcan4.keys():
                context.stkcan4.pop(stk)
            if stk in context.stkcan5.keys():
                context.stkcan5.pop(stk)
            if stk in context.stkcan6.keys():
                context.stkcan6.pop(stk)
#知飞科技原创 · 新元blank
    #建仓
    if now.hour==11 and now.minute == 28:
        popListwow = []
        for stk in context.portfolio.positions.keys():
            if context.portfolio.positions[stk].quantity != 0:
                if (context.portfolio.positions[stk].avg_price) != 0:
                    if bar_dict[stk].close / (context.portfolio.positions[stk].avg_price) -1 >= 0.01:
                    #如果 当前价和成本价的差价大于预定值 则卖出
                        order_target_value(stk, 0)
                        print('低止盈',stk)
                        popListwow.append(stk)
        for stk in popListwow:
            if stk in context.stkcan1.keys():
                context.stkcan1.pop(stk)
            if stk in context.stkcan2.keys():
                context.stkcan2.pop(stk)
            if stk in context.stkcan3.keys():
                context.stkcan3.pop(stk)
            if stk in context.stkcan4.keys():
                context.stkcan4.pop(stk)
            if stk in context.stkcan5.keys():
                context.stkcan5.pop(stk)
            if stk in context.stkcan6.keys():
                context.stkcan6.pop(stk)
        #定义大股票池集合，三个，一个全股allso，一个小市值alls1，一个大市值alls2
        buyListone = Select(context,bar_dict,context.alls0)
        buyListtwo = Select(context,bar_dict,context.alls1)
        buyListthree = Select(context,bar_dict,context.alls2)
        #定义大股票池中的六个选股函数，放进buylist中
        #知飞科技原创 · 新元blank
        context.buyList1 = Select1(context,bar_dict,buyListone)  #全股
        buyCount1 = context.holdSize1-len(context.stkcan1.keys()) #股数限制
        context.buyList1 = context.buyList1[:buyCount1]                   #定义持仓1股数限制
        context.buyList2 = Select2(context,bar_dict,buyListone)  #全股2
        buyCount2 = context.holdSize2-len(context.stkcan2.keys()) #股数限制
        context.buyList2 = context.buyList2[:buyCount2]                   #定义持仓2股数限制
        context.buyList3 = Select3(context,bar_dict,buyListtwo)  #小市值
        buyCount3 = context.holdSize3-len(context.stkcan3.keys()) #股数限制
        context.buyList3 = context.buyList3[:buyCount3]                   #定义持仓3股数限制
        context.buyList4 = Select4(context,bar_dict,buyListtwo)  #小市值2
        buyCount4 = context.holdSize4-len(context.stkcan4.keys()) #股数限制
        context.buyList4 = context.buyList4[:buyCount4]                   #定义持仓4股数限制
        context.buyList5 = Select5(context,bar_dict,buyListthree)#大市值
        buyCount5 = context.holdSize5-len(context.stkcan5.keys()) #股数限制
        context.buyList5 = context.buyList5[:buyCount5]                   #定义持仓5股数限制
        context.buyList6 = Select6(context,bar_dict,buyListthree)#大市值2
        buyCount6 = context.holdSize6-len(context.stkcan6.keys()) #股数限制
        context.buyList6 = context.buyList6[:buyCount6]                   #定义持仓6股数限制
        #定义大盘日内数据
        panhis1 = history(3,'1d','close')['000001.XSHE'].values  #大盘历史收盘值
        pankai1 = history(3,'1d','close')['000001.XSHE'].values  #大盘历史开盘值
        panhigh = bar_dict['000001.XSHE'].high                      #大盘今日最高值
        panlow = bar_dict['000001.XSHE'].low                        #大盘今日最低值
        pankai = bar_dict['000001.XSHE'].open                       #大盘今日开盘值
        panclose = bar_dict['000001.XSHE'].last                     #大盘今日当下时刻值
        global panret
        #大盘上影线长度
#知飞科技原创 · 新元blank
        if panclose>pankai:
            context.panret = (panhigh - panclose) / panhigh
        elif panclose<pankai:
            context.panret = (panhigh - pankai) / panhigh
        #大盘特定条件下再买入
        for stk in context.buyList1:
            if stk not in context.portfolio.positions.keys():
                if not (panhis1[2]>panhis1[1]>panhis1[0] and context.panret > 0.0025):
                    stkinfo1 = {}
                    stkinfo1['times'] = 1
                    stkinfo1['holddays'] = 1
                    context.stkcan1[stk] = stkinfo1
                    order_lots(stk,1)
                    print(stk)
        for stk in context.buyList2:
            if stk not in context.portfolio.positions.keys():
                if not (panhis1[2]>pankai1[2] and panhis1[1]>pankai1[1] and panclose<panhis1[2] and context.panret > 0.0015):
                    stkinfo2 = {}
                    stkinfo2['times'] = 1
                    stkinfo2['holddays'] = 1
                    context.stkcan2[stk] = stkinfo2
                    order_lots(stk,1)
                    print(stk)
        for stk in context.buyList3:
            if stk not in context.portfolio.positions.keys():
                if not (panhis1[2]<pankai1[2] and panhis1[0]<pankai1[0] and context.panret > 0.001):
                    stkinfo3 = {}
                    stkinfo3['times'] = 1
                    stkinfo3['holddays'] = 1
                    context.stkcan3[stk] = stkinfo3
                    order_lots(stk,1)
                    print(stk)
#知飞科技原创 · 新元blank
        for stk in context.buyList4:
            if stk not in context.portfolio.positions.keys():
                if not (panhis1[1]<pankai1[1] and panhis1[0]<pankai1[0] and context.panret > 0.001):
                    stkinfo4 = {}
                    stkinfo4['times'] = 1
                    stkinfo4['holddays'] = 1
                    context.stkcan4[stk] = stkinfo4
                    order_lots(stk,1)
                    print(stk)
        for stk in context.buyList5:
            if stk not in context.portfolio.positions.keys():
                if not (panhis1[2]<pankai1[2] and panclose<panhis1[2] and context.panret > 0.001):
                    stkinfo5 = {}
                    stkinfo5['times'] = 1
                    stkinfo5['holddays']=1
                    context.stkcan5[stk] = stkinfo5
                    order_lots(stk,1)
                    print(stk)
        for stk in context.buyList6:	
            if stk not in context.portfolio.positions.keys():
                if not (panhis1[1]<pankai1[1] and panclose < panhis1[2]*0.998 and context.panret > 0.003):
                    stkinfo6 = {}
                    stkinfo6['times'] = 1
                    stkinfo6['holddays']=1
                    context.stkcan6[stk] = stkinfo6
                    order_lots(stk,1)
                    print(stk)