# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
策略：分析5日均线和30日均线，在金叉把所有钱（开始有100000元）买入股票，死叉抛出所有股票
@author: jluo27
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tushare as ts

df = pd.read_csv("C:/Private/Analysis/python/mine/stock/000931.csv",index_col="date",parse_dates=["date"]) 

df["ma5"]=np.nan
df["ma30"]=np.nan

# for i in range(4,len(df)):
#     df.loc[df.index[i],"ma5"] = df["close"][i-4:i+1].mean()
# for i in range(29, len(df)):
#     df.loc[df.index[i], "ma30"] = df["close"][i-29:i + 1].mean()

df["ma5"]=df["open"].rolling(5).mean()                                 #5日双均线
df["ma30"]=df["open"].rolling(30).mean()                              #30日双均线

#处理数据：丢掉nan并取到需要的时间段
df = df.dropna()
df = df["2006-01-01":]

#取到金叉和死叉的值
golden_cross = []
death_cross = []
# for i in range(1,len(df)):
#     if df["ma5"][i] >= df["ma30"][i]  and  df["ma5"][i-1] < df["ma30"][i-1]          #5日均线作天小于30日均线，在今天大于等于30日均线
#         golden_cross.append(df.index[i].to_pydatetime())
#
#     if df["ma5"][i] <= df["ma30"][i] and df["ma5"][i - 1] > df["ma30"][i - 1]       #5日均线昨天大于30日均线，在今天小于等于30日均线
#         death_cross.append(df.index[i].to_pydatetime())

sr1 = df["ma5"] < df["ma30"]
sr2 = df["ma5"] >= df["ma30"]
death_cross = df[sr1 & sr2.shift(1)].index
golden_cross = df[~((sr1) | (sr2.shift(1)))].index          #golden_cross = df[((~sr1) & (~sr2.shift(1)))].index

#把金叉和死叉合并起来，一个金叉接着一个死叉排序
sr1 = pd.Series(1,index=golden_cross)
sr2 = pd.Series(0,index=death_cross)
sr= sr1.append(sr2).sort_index()


first_money=10000
money= first_money
hold=0                             #有多少股的股票
for i in range(0,len(sr)):
    p = df["open"][sr.index[i]]        #单股价格
    if sr.iloc[i] == 1:            #金叉       策略相反？？？
        buy=(money// (100*p))     #可以买多少手股票
        hold += buy*100          #股票数
        money-= buy*100*p         #剩余多少钱
    else:
        money += hold*p          #卖出股票
        hold = 0
p = df["close"][-1]
now_money= hold*p +money
print(now_money)