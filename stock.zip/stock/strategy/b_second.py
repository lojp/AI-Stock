# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
"""


import numpy as np
import pandas as pd
df = pd.read_csv("C:/Private/Analysis/python/mine/stock/000931.csv",index_col="date",parse_dates=["date"])       #从600519.csv中读取数据，date列作为索引
df[(df["close"]-df["open"])/df["open"] > 0.03 ].index                 #收盘比开盘上涨3% 的所有日期
df[(df["open"]-df["close"].shift(1)) /df["close"].shift(1) < -0.02].index   #df["close"].shift(1) 前一天收盘价

df_monthly=df.resample("M").first()                             #每月的第一个交易日，日期看着是最后一天，数据是第一天的
df_yearly=df.resample("A").last()                         #每年的最后一个交易日
df_yearly=df_yearly.iloc[:-1,:]                      #去掉最后一行，因为本年最后还没到，取得是昨天的数据
cost=0
num=0
for year in range(2006,2019):
    cost += (df_monthly[str(year)]["open"] *100 ).sum()           #df_monthly[str(year)]["open"] 每月的开盘价买进
    num= 100 * len(df_monthly[str(year)]["open"])                 #每月买一手，一手是100股
    if year !=2018:
        cost -= df_yearly[str(year)]["open"][0] *num              #卖出股票，抵消花费
        num = 0
cost -= num *df["close"].iloc[-1]
print(-cost)




#df.resample("W").mean()                               #每周的平均值
#df.resample("W").first()                             #每周的第一天