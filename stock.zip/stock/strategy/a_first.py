# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
"""

import tushare as ts
import os

proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

df = ts.get_k_data("000931",start="1990-01-01")
df.to_csv("C:/Private/Analysis/python/mine/stock/000931.csv",index=False)    