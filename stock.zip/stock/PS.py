# -*- coding: UTF-8 -*-
#1)不要问我tushare、pandas、pytdx、tslearn、pywt怎么安装这些问题,请自行百度； 一般pip install 即可。
#2)本程序需要300以上tushare积分才可运行,积分获取方法请参考https://tushare.pro/document/1?doc_id=13 ,当然你通过https://tushare.pro/register?reg=100017 注册tushare我会谢谢你的。
#3)这是预测概率的程序,策略原理请参考https://zhuanlan.zhihu.com/c_1100040485648797696 的一个基于机器学习的打板策略分享系列，欢迎在知乎交流。
import os
import tushare as ts
import pandas as pd
import numpy as np
import warnings
import time
from datetime import datetime
#忽略警告信息
warnings.filterwarnings("ignore")
#初始化当天日期
today=str(datetime.now().strftime('%Y%m%d'))

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
mypath = 'C:\\Private\\Analysis\\python\\mine\\stock\\'
os.chdir(mypath)

proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

ts_token='0c98ac2886e4331d7120a91573d3d025ba2eec7c96bfac77f9b7153d'
ts.set_token(ts_token)
pro = ts.pro_api()
df = pro.query('daily_basic', ts_code='', trade_date='20200428',fields='ts_code,trade_date,total_mv,circ_mv,pe,pb,ps,ps_ttm')
df.to_csv('stock_ps.csv',encoding = 'utf-8_sig')
