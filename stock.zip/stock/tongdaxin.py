# -*- coding: utf-8 -*-
"""
Created on Jun 21 09:37:17 2017

@author: jluo27
"""
import os
import tushare
from funcat import *


proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

T("20170623")
S("000001.XSHG")
print(O, H, L, C)