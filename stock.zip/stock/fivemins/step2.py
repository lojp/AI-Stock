# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""

import numpy as np
import pandas as pd
import tushare as ts
import datetime
import time
import tushare as ts
import os
 
proxy = 'fmcpr005-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy 
 
 
 
data_dir = 'C:\\Private\\Analysis\\python\\mine\\stock\\fivemins\\'  #下载数据的存放路径
 
#ts.get_sz50s() #获取上证50成份股  返回值为DataFrame：code股票代码 name股票名称
 
cal_dates = ts.trade_cal() #返回交易所日历，类型为DataFrame, calendarDate  isOpen
           
#根据分笔成交数据生成1分钟线
#根据分笔成交数据生成1分钟线
def gen_min_line(symbol, date):
          global data_dir
          str_date=str(date)
          dir=data_dir+symbol+'\\'+str(date.year)+'\\'+str(date.month)
          tickfile=dir+'\\'+symbol+'_'+str_date+'_tick_data.h5'
          minfile=dir+'\\'+symbol+'_'+str_date+'_1min_data.h5'
          if (os.path.exists(tickfile)) and (not os.path.exists(minfile)):
                    hdf5_file=pd.HDFStore(tickfile, 'r')
                    df=hdf5_file['data'] 
                    hdf5_file.close()
                    print "Successfully read tick file: "+tickfile
                    if df.shape[0]<10: #TuShare即便在停牌期间也会返回tick data，并且只有三行错误的数据，这里利用行数小于10把那些unexpected tickdata数据排除掉
                              print ("No tick data read from tick file, skip generating 1min line")
                              return 0
                    df['time']=str_date+' '+df['time']
                    df['time']=pd.to_datetime(df['time'])
                    df=df.set_index('time')
                    price_df=df['price'].resample('1min').ohlc()
                    price_df=price_df.dropna()
                    vols=df['volume'].resample('1min').sum()
                    vols=vols.dropna()
                    vol_df=pd.DataFrame(vols,columns=['volume'])
                    amounts=df['amount'].resample('1min').sum()
                    amounts=amounts.dropna()
                    amount_df=pd.DataFrame(amounts,columns=['amount'])
                    newdf=price_df.merge(vol_df, left_index=True, right_index=True).merge(amount_df, left_index=True, right_index=True)
                    hdf5_file2=pd.HDFStore(minfile, 'w')
                    hdf5_file2['data']=newdf
                    hdf5_file2.close()
                    print ("Successfully write to minute file: "+minfile)
 
dates=get_date_list(datetime.date(2019,6,3), datetime.date(2019,6,19))
stocks=get_all_stock_id()
for stock in stocks:
    for date in dates:
        gen_min_line(stock, date)
