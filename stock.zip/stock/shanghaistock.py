#encoding:utf8

"""
@author:lojp
@contact:lojp@qq.com
@time:2017/5/9 22:47
"""

from selenium import webdriver
import time
from datetime import datetime, timedelta
import string
import os
import xlrd
from xlutils.copy import copy

proxy = 'fmcpr003-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy


data = xlrd.open_workbook('C:/Users/jluo27/Desktop/stock.xlsx')
wb = copy(data)
sht = data.sheets()[0]  
nrows = sht.nrows
driver=webdriver.Chrome('C:\Private\Analysis\python\mine\chromedriver.exe')
driver.get("http://www.sse.com.cn/market/stockdata/overview/day/")

for i in range(nrows)[1:]:
	try:
		print('Now have finished',i," Times/ ","{:.1f}%".format(i*100/nrows))
		searchdate = datetime(*xlrd.xldate_as_tuple(sht.cell(i,0).value, 0)).strftime('%Y-%m-%d')

		time.sleep(4)
		driver.execute_script("var setDate=document.getElementById('start_date2');setDate.removeAttribute('readonly');")

		#定位到日期控件
		setDatElement=driver.find_element_by_xpath("//input[@id='start_date2']")

		#清除内容
		setDatElement.clear()
		setDatElement.send_keys(searchdate)
		driver.find_element_by_id("btnQuery").click()
		time.sleep(5)
		totalValueA_sh=driver.find_element_by_xpath('//*[@id="tableData_934"]/div[2]/table/tbody/tr[2]/td[3]/div').text
		negotiableValueA_sh=driver.find_element_by_xpath('//*[@id="tableData_934"]/div[2]/table/tbody/tr[3]/td[3]/div').text
		trdAmtA_sh=driver.find_element_by_xpath('//*[@id="tableData_934"]/div[2]/table/tbody/tr[5]/td[3]/div').text
		profitRateA_sh=driver.find_element_by_xpath('//*[@id="tableData_934"]/div[2]/table/tbody/tr[7]/td[3]/div').text

		#print(negotiableValueA_sh,trdAmtA_sh,profitRateA_sh)
		sh = wb.get_sheet(0)
		sh.write(i,3,float(totalValueA_sh))
		sh.write(i,4,float(negotiableValueA_sh))
		sh.write(i,5,float(trdAmtA_sh))
		sh.write(i,6,float(profitRateA_sh))
		wb.save('C:/Users/jluo27/Desktop/xhxh.xls')
	except:
		pass