#! usr/bin/python #coding=utf-8
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
import pandas as pd
import tushare as ts
import os

proxy = 'fmcpr001-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy


e = ts.get_today_all()
code = e[u'code']
name = e[u'name']
per = e[u'per'] # 市盈率
tt = e[u'turnoverratio']	# 换手率
cc = e[u'changepercent']	# 涨跌幅
mm = e[u'mktcap']	# 总市值

print("total:",len(name))
print(type(e))

# idx = len(name)
# total = 0
# while idx > 0:
	# idx -= 1
    # # 市盈率在0-30倍之间，且今日换手率>1%，涨幅超2%的
	# if per[idx] < 400 and per[idx] > 0 and tt[idx] > 2 and cc[idx] > 7:
		# print (name[idx],":",per[idx],":",tt[idx],":",cc[idx],":",round(mm[idx]/10000,3))
		# total += 1
# print ("total:",total,"/",len(name))




# idx = len(name)
# total = 0
# while idx > 0:
	# idx -= 1
	# # 涨停股票
	# if cc[idx] > 9.5:
		# total += 1
		# print ("@@@@:",code[idx],":",name[idx],":",cc[idx])
# print ("total:",total,"/",len(name))

