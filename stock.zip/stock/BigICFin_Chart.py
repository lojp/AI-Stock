# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 09:37:17 2017
must use 64bit to open ODBC  'Ctrl + Shift + F1'
@author: jluo27
"""
import os
import tushare as ts
import pandas as pd
import numpy as np
import warnings
import time
from datetime import datetime
import matplotlib.pyplot as plt
import numpy as np
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
#忽略警告信息
warnings.filterwarnings("ignore")

#初始化当天日期
today=str(datetime.now().strftime('%Y%m%d'))

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
mypath = 'C:\\Private\\Analysis\\python\\mine\\stock\\'
os.chdir(mypath)

proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

ts_token='0c98ac2886e4331d7120a91573d3d025ba2eec7c96bfac77f9b7153d'
ts.set_token(ts_token)
pro = ts.pro_api()
# df = pro.top10_holders(ts_code='300456.SZ', start_date='20190901', end_date='20190930')
# print(df.dtypes)

price_open_df = pd.read_csv('stock_data.csv',encoding = 'utf-8_sig')
df = pd.read_csv('topholders.CSV', encoding='utf_8')
df['code'] = df['ts_code'].str[:6]
ndf = df[df['holder_name'].str.contains('医药') & df['holder_name'].str.contains('基金')]
new_df = ndf.loc[(ndf['ann_date'] == ndf.groupby('ts_code')['ann_date'].transform('max'))]
# new_df = df.loc[(df['ann_date'] == df.groupby('ts_code')['ann_date'].transform('max'))]
mdf = pd.merge(new_df[['ts_code','end_date','holder_name','hold_ratio','hold_amount']], price_open_df[['ts_code','name','trade','per','pb','mktcap','nmc']],how='left', on=['ts_code'])
mdf['amount'] = mdf['trade'] * mdf['hold_amount']
mdf['amount_yi'] = mdf['amount']/100000000
mdf = mdf.sort_values(by=['amount_yi'], ascending=False)
print(mdf)

# ttl_df = pd.pivot_table(mdf,index=['holder_name'], values=['amount_yi'],aggfunc=np.sum).reset_index()
# ttl_df = ttl_df.sort_values(by=['amount_yi'], ascending=False)
# ttl_df.to_csv('topholder.csv',encoding = 'utf-8_sig',index=False)
# print(ttl_df)

# n = mdf['name']
# amt = mdf['amount_yi']
# rat = mdf['hold_ratio']
# pe = mdf['pb']

# colors = np.random.rand(len(rat))  # 颜色数组
# size = amt
# fig, ax = plt.subplots()
# ax.scatter(rat, pe, s=size*10, c=colors, alpha=0.6)  # 画散点图, alpha=0.6 表示不透明度为 0.6
# for i, txt in enumerate(n):
    # ax.annotate(txt, (rat[i], pe[i]), ha='center',fontproperties=zhfont1,size=10)
# plt.ylabel('pb')  # 纵坐标轴标题
# plt.xlabel('hold_ratio')  # 横坐标轴标题
# plt.show()


