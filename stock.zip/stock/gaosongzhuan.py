# -*- coding: utf-8 -*-
"""
Created on Fri Sep 23 15:45:05 2016
@author: edgarcai
"""


import tushare as ts
import datetime
import pandas as pd
import os

proxy = 'fmcpr003-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy


# 基本面数据
basic = ts.get_stock_basics()

# 行情和市值数据
hq = ts.get_today_all()

#当前股价,如果停牌则设置当前价格为上一个交易日股价
hq['trade'] = hq.apply(lambda x:x.settlement if x.trade==0 else x.trade, axis=1)

#分别选取流通股本,总股本,每股公积金,每股收益
basedata = basic[['outstanding', 'totals', 'reservedPerShare', 'eps']]

#选取股票代码,名称,当前价格,总市值,流通市值
hqdata = hq[['code', 'name', 'trade', 'mktcap', 'nmc']]

#设置行情数据code为index列
hqdata = hqdata.set_index('code')

#合并两个数据表
data = basedata.merge(hqdata, left_index=True, right_index=True)

data['mktcap'] = data['mktcap'] / 10000
data['nmc'] = data['nmc'] / 10000

#每股公积金>=5
res = data.reservedPerShare >= 5
#流通股本<=3亿
out = data.outstanding <= 30000
#每股收益>=5毛
eps = data.eps >= 0.5
#总市值<60亿
mktcap = data.mktcap <= 60

allcrit = res & out & eps & mktcap
selected = data[allcrit]
print(selected[['name','trade','reservedPerShare','eps','mktcap','nmc']])