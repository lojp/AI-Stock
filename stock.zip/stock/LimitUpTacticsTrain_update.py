# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
""" 
import os
#1)不要问我tushare、pandas、pytdx、tslearn、pywt怎么安装这些问题,请自行百度； 一般pip install 即可。
#2)本程序需要300以上tushare积分才可运行,积分获取方法请参考https://tushare.pro/document/1?doc_id=13 ,当然你通过https://tushare.pro/register?reg=100017 注册tushare我会谢谢你的。
#3)这是训练模型的程序,策略原理请参考https://zhuanlan.zhihu.com/c_1100040485648797696 的一个基于机器学习的打板策略分享系列，欢迎在知乎交流。
import tushare as ts
import pandas as pd
import numpy as np
import datetime
import pytdx
import pywt
import tslearn
# import talib
import pickle
import os
import math
import peakutils
from scipy import stats as st
from datetime import datetime
from pytdx.hq import TdxHq_API
from tslearn.utils import save_timeseries_txt ,load_timeseries_txt,to_time_series_dataset,to_time_series
from tslearn.neighbors import KNeighborsTimeSeriesClassifier
from tslearn.clustering import TimeSeriesKMeans,silhouette_score,GlobalAlignmentKernelKMeans
from tslearn.preprocessing import TimeSeriesResampler
from tqdm import *
import warnings
#忽略警告信息
warnings.filterwarnings("ignore")

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
mypath = 'C:\\Private\\Analysis\\python\\mine\\stock\\'
os.chdir(mypath)

proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

#☆常量定义,改这句即可运行.请支持tushare和米哥. 
ts_token='0c98ac2886e4331d7120a91573d3d025ba2eec7c96bfac77f9b7153d'
#初始化当天日期
today=str(datetime.now().strftime('%Y%m%d'))
#pytdx服务器地址
pytdx_server='119.147.212.81'
#pytdx服务器端口
pytdx_port=7709
#初始化TS_API接口
def get_ts_api():
    ts.set_token(ts_token)
    pro = ts.pro_api()
    return pro
#初始化pytdx接口
def get_pytdx_api():
    api = TdxHq_API(auto_retry=True, raise_exception=True,heartbeat=True)
    return api
#获取全部股票每日重要的基本面指标,主要用到收市价和自由流通股本
def build_stock_daily_basic(trade_date):
    pro=get_ts_api()
    df_stock_daily_basic=pro.daily_basic(trade_date=trade_date)
    return df_stock_daily_basic
#获取股票日线行情,主要用到涨跌幅和最高价和最低价
def build_stock_daily(trade_date):
    pro=get_ts_api()
    df_stock_daily=pro.daily(trade_date=trade_date)
    return df_stock_daily
#使用pytdx获取历史分钟线数据
def get_stock_minute_data(api,stock_code,pre_close,free_share,stock_date):
    df_minute_line=api.to_df(api.get_history_minute_time_data(select_market_code(stock_code),stock_code[0:6],stock_date))
    #https://zhuanlan.zhihu.com/p/62339900
    df_minute_line['abs_close']=df_minute_line['price']/pre_close
    df_minute_line['abs_vol']=df_minute_line['vol']/(free_share*100) 
    #去掉特殊数值
    df_minute_line=df_minute_line.replace(np.NaN,0)
    df_minute_line=df_minute_line.replace(np.inf,0)
    #删掉无效字段
    # df_minute_line=df_minute_line.drop(columns=['price','vol'], axis=1)
    #截取从开市到close首次到达最高点的分钟线
    index_abs_close_max=df_minute_line[df_minute_line['abs_close']==df_minute_line['abs_close'].max()].index.min()+1
    df_minute_line=df_minute_line.iloc[0:index_abs_close_max]
    #重构索引
    df_minute_line=df_minute_line.reset_index(drop=True)
    return df_minute_line
#根据股票代码确认是深市还是沪市
def select_market_code(code):
    market_code=0
    if code.startswith('60',0,2):
        market_code=1
    return market_code
#训练分钟数据 https://zhuanlan.zhihu.com/p/62784517
def train_minute_data():
    #加载训练数据
    close_x=load_timeseries_txt('stock_minute_train_close.txt')
    y=np.loadtxt('stock_minute_label_data.csv',delimiter=',',dtype=int)
    #如果已有模型文件从本地加载
    if os.path.exists('LimitUpTacticsClose.h5'):
        fr_close=open('LimitUpTacticsClose.h5', 'rb')
        clf_close = pickle.load(fr_close, fix_imports=True)
    #如果本地无模型文件新创建一个
    else:
        clf_close=KNeighborsTimeSeriesClassifier(n_neighbors =2,metric="dtw")
    clf_close.fit(close_x, y)
    #保存模型文件到本地
    with open('LimitUpTacticsClose.h5', 'wb') as fw_close:
        pickle.dump(clf_close, fw_close,fix_imports=True)    
    #加载文件
    df_top_three=pd.read_csv('vol_top_three.csv',encoding='gbk')
    #对价格变量进行四舍五入
    df_top_three['range']=round(df_top_three['abs_close'],2)
    #构建空白DataFrame
    df_step=pd.DataFrame()
    #获得各价格段的80%置信区间
    for name, group in df_top_three.groupby('range'):
        mean=np.mean(group['abs_vol'].values)
        std=st.sem(group['abs_vol'].values)
        #按80%的置信区间取上下界
        conf_intveral = st.norm.interval(0.8, loc=mean, scale=std)
        #判断元组的上下界元素都不为Nan
        if(name!=np.nan)and(math.isnan(conf_intveral[0])==False)and(math.isnan(conf_intveral[1])==False):
            df_step=df_step.append(pd.DataFrame(data=[[name,conf_intveral[0],conf_intveral[1]]],columns=['range','lower_limit','upper_limit']), ignore_index=True)
    df_step.to_csv('df_step.csv',encoding='gbk',index=False)
#构建训练数据并训练
def build_train_data(start_date,end_date):
    pro=get_ts_api()
    api=get_pytdx_api()
    stock_minute_train_close=[]
    stock_minute_train_vol=[]
    stock_minute_label_data=[]
    #获取起止日期间的交易日
    df_trade_cal=pro.trade_cal(exchange='', start_date=start_date, end_date=end_date, fields='cal_date', is_open='1')
    # df_trade_cal=df_trade_cal[(df_trade_cal['is_open']==1)]
    tsr_close=TimeSeriesResampler(sz=24)
    tsr_vol=TimeSeriesResampler(sz=10)
    df_top_three=pd.DataFrame(columns=['stock_code','trade_date','abs_vol','abs_close'])
    with api.connect(pytdx_server, pytdx_port):
        for j in tqdm(range(0,len(df_trade_cal))):
            cal_date=df_trade_cal.iloc[j]['cal_date']
            df_stock_daily=build_stock_daily(cal_date)
            # df_stock_daily_basic=build_stock_daily_basic(cal_date)  ###要积分，暂时屏蔽
            for i in tqdm(range(0,len(df_stock_daily))):
                ts_code=df_stock_daily.iloc[i]['ts_code']
                pct_chg=df_stock_daily.iloc[i]['pct_chg']
                #非新股上市
                if(pct_chg<11)and(pct_chg>-11):
                    #获取上一交易日收市价
                    pre_close=df_stock_daily.iloc[i]['pre_close']
                    #获取股票自由流通股本
                    # free_share=df_stock_daily_basic[df_stock_daily_basic['ts_code']==ts_code]['free_share'].values[0]
                    free_share= 5000
                    df_minute_temp=get_stock_minute_data(api, ts_code, pre_close, free_share, cal_date)
                    if(len(df_minute_temp)>0):
                        #涨幅大于9%的取成交量前三的分钟线成交量数据
                        if(pct_chg>=9):
                            #取成交量前三的分钟线成交量数据
                            df_temp=df_minute_temp.sort_values(by='abs_vol',ascending=False).head(3)
                            df_temp['stock_code']=ts_code
                            df_temp['trade_date']=pd.to_datetime(cal_date)
                            df_temp['abs_close']=df_temp['abs_close']-1
                            df_top_three=df_top_three.append(df_temp, ignore_index=True)

                        stock_minute_label_data.append(round(pct_chg,0))
                        #提取价格的高频信号                  
                        A2,D6,D5,D4=pywt.wavedec(df_minute_temp['abs_close'].values, 'db4',mode='symmetric',level=3)
                        stock_minute_train_close.append(to_time_series(A2))
                        
    #重新采样为24个点的信号
    stock_minute_train_close=tsr_close.fit_transform(stock_minute_train_close)
    ts_train_close=to_time_series_dataset(stock_minute_train_close,dtype=np.float32)
    where_are_nan = np.isnan(ts_train_close)
    ts_train_close[where_are_nan] = 0
    save_timeseries_txt('stock_minute_train_close.txt', ts_train_close)
        
    #保存标签数据
    np.savetxt('stock_minute_label_data.csv', stock_minute_label_data,delimiter=',',fmt='%i')
    #保存成交量前三的汇总数据
    df_top_three.to_csv('vol_top_three.csv',encoding='gbk',index=False)
if __name__ == "__main__":
    #☆如果你能填为19940808并训练成功,请务必发一份模型文件给我,哪怕是20190101也好
    build_train_data('20190101', today)
    train_minute_data()