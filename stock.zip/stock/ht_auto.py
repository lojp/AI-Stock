# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
"""

import tushare as ts
import os
# from tushare.util.upass import set_broker


ts.set_broker('htzq',user = '056000053523',passwd='208057')
csc = ts.TraderAPI('htzq')
csc.login()

# get_broker()