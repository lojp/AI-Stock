# -*- coding: UTF-8 -*-
#1)不要问我tushare、pandas、pytdx、tslearn、pywt怎么安装这些问题,请自行百度； 一般pip install 即可。
#2)本程序需要300以上tushare积分才可运行,积分获取方法请参考https://tushare.pro/document/1?doc_id=13 ,当然你通过https://tushare.pro/register?reg=100017 注册tushare我会谢谢你的。
#3)这是预测概率的程序,策略原理请参考https://zhuanlan.zhihu.com/c_1100040485648797696 的一个基于机器学习的打板策略分享系列，欢迎在知乎交流。
import os
import tushare as ts
import pandas as pd
import numpy as np
import datetime
import pytdx
import pywt
import tslearn
# import talib
import pickle
import os
import multiprocessing
from datetime import datetime
from pytdx.hq import TdxHq_API
from tslearn.neighbors import KNeighborsTimeSeriesClassifier
from tslearn.preprocessing import TimeSeriesResampler
from tslearn.utils import save_timeseries_txt ,load_timeseries_txt,to_time_series_dataset,to_time_series
import warnings
#忽略警告信息
warnings.filterwarnings("ignore")

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
mypath = 'C:\\Private\\Analysis\\python\\mine\\stock\\'
os.chdir(mypath)



proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy



#使用CPU核心设置
thread_count=int(multiprocessing.cpu_count()-2)
#☆常量定义,改这句即可运行.请支持tushare和米哥. 
ts_token='0c98ac2886e4331d7120a91573d3d025ba2eec7c96bfac77f9b7153d'
#初始化当天日期
today=str(datetime.now().strftime('%Y%m%d'))
#pytdx服务器地址
pytdx_server='119.147.212.81'
#pytdx服务器端口
pytdx_port=7709
#概率阈值
probability_threshold=0.5
#初始化TS_API接口
def get_ts_api():
    ts.set_token(ts_token)
    pro = ts.pro_api()
    return pro
#初始化pytdx接口
def get_pytdx_api():
    api = TdxHq_API(auto_retry=True, raise_exception=True,heartbeat=True)
    return api
#传入五个参数，分别是实例化的TdxHq_API对象、股票代码、上一交易日的收市价，上一交易日自由流通股本数和要获取的分钟线的日期
def get_stock_minute_data(api,stock_code,pre_close,free_share,stock_date):
    df_minute_line=api.to_df(api.get_security_bars(8, get_market_code(stock_code),stock_code[0:6], 0, 800))
    df_minute_line['datetime']=pd.to_datetime(df_minute_line['datetime'])
    df_minute_line=df_minute_line[(df_minute_line['datetime']>=stock_date)]
    df_minute_line['abs_close']=df_minute_line['close']/pre_close
    df_minute_line['abs_vol']=df_minute_line['vol']/(free_share*100)           
    #去掉特殊数值
    df_minute_line=df_minute_line.replace(np.NaN,0)
    df_minute_line=df_minute_line.replace(np.inf,0)
    #删掉无用字段
    df_minute_line=df_minute_line.drop(['open','close','high','low','vol','amount','year','month','day','hour','minute','datetime'], axis=1)    
    #重构索引
    df_minute_line=df_minute_line.reset_index(drop=True)
    return df_minute_line
#根据股票代码确认是深市还是沪市
def get_market_code(code):
    market_code=0
    if code.startswith('60',0,2):
        market_code=1
    return market_code
#获取上一交易日
def get_last_trade_date(stock_date):
    pro=get_ts_api()
    df_trade_cal=pro.trade_cal()
    df_trade_cal=df_trade_cal[(df_trade_cal['is_open']==1)&(df_trade_cal['cal_date']<str(stock_date))]
    return df_trade_cal.tail(1)['cal_date'].values[0]
#☆请自行实现你的股票池方法
def get_stock_pool():
    #return ['600336.SH','002255.SZ','000720.SZ','601689.SH','000413.SZ','300749.SZ','603679.SH']
    return ['600758.SH']
#获取某只股票上一交易日的收市价和自由流通股本
def get_stock_daily_basic(stock_date):
    pro=get_ts_api()
    df_stock_daily_basic=pro.daily_basic(trade_date=stock_date)
    return df_stock_daily_basic
#获取股票日线行情,主要用到涨跌幅和最高价和最低价
def get_stock_daily(trade_date):
    pro=get_ts_api()
    df_stock_daily=pro.daily(trade_date=trade_date)
    return df_stock_daily
#☆在此实现你自己对于该股票今天是否会涨停的判断,例如我会去5挡委买看看
# def your_extra_judge(api,stock_code,pre_close,df_step,free_share):
    # #某个不可描述的迷之接口
    # df_real_time=******
    # df_real_time=df_real_time.replace(to_replace='', value=0)
    # #五档委买价格数组
    # price_range=[df_real_time['bid1'][0],df_real_time['bid2'][0],df_real_time['bid3'][0],df_real_time['bid4'][0],df_real_time['bid5'][0]]
    # #五档委买手数数组
    # vol_range=[df_real_time['bid_vol1'][0],df_real_time['bid_vol2'][0],df_real_time['bid_vol3'][0],df_real_time['bid_vol4'][0],df_real_time['bid_vol5'][0]]
    # flag=False
    # for i in range(0,len(price_range)):
        # #计算当前相对价格
        # abs_price=round(price_range[i]/pre_close-1,2)
        # #查找大于当前相对价格的档位
        # df_step_sub=df_step[df_step['range']>=abs_price]
        # #计算相对委买力度
        # abs_vol=vol_range[i]/(free_share*100)
        # for j in range(0,len(df_step_sub)):
            # if(abs_vol>=df_step_sub.iloc[j]['lower_limit'])and(abs_price>0):
                # flag=True
    # print(flag)
    # return flag
#实时预测
def real_time_predict_proba():
    #加载自选股票池,请自行实现
    stock_pool=get_stock_pool()
    #获取上一交易日
    last_trade_date=get_last_trade_date(today)
    #获取上一交易日的基本信息
    stock_daily_basic=get_stock_daily_basic(last_trade_date)
    stock_daily=get_stock_daily(last_trade_date)
    multiprocessing.freeze_support()
    df_step=pd.read_csv('df_step.csv',encoding='gbk')
    pool = multiprocessing.Pool(processes = min(thread_count,len(stock_pool)))
    #加载模型文件
    if os.path.exists('LimitUpTacticsClose.h5'):
        fr_close=open('LimitUpTacticsClose.h5', 'rb')
        clf_close = pickle.load(fr_close, fix_imports=True)
        #循环启动后台进程
        for i, stock_code_temp in enumerate(stock_pool): 
            stock_daily_basic_temp=stock_daily_basic[(stock_daily_basic['ts_code']==stock_code_temp)]
            stock_daily_temp=stock_daily[(stock_daily['ts_code']==stock_code_temp)]
            if(len(stock_daily_basic_temp)>0)and(len(stock_daily_temp)>0):
                #获取上一交易日收市价
                pre_close=stock_daily_basic_temp['close'].values[0]
                #获取上一交易自由流通股本
                free_share=stock_daily_basic_temp['float_share'].values[0]
                #多进程版预测
                pool.apply_async(sub_process_predict_proba, (stock_code_temp,pre_close,free_share,today,clf_close,df_step, ))
    pool.close()
    pool.join()  
#多进程版预测
def sub_process_predict_proba(stock_code,pre_close,free_share,stock_date,clf_close,df_step):
    api=get_pytdx_api()
    tsr_close=TimeSeriesResampler(sz=24)
    try:
        with api.connect(pytdx_server, pytdx_port):
            df_minute_line=get_stock_minute_data(api, stock_code, pre_close, free_share, stock_date)
            A2,D6,D5,D4=pywt.wavedec(df_minute_line['abs_close'].values, 'db4',mode='symmetric',level=3)
            probability_close=clf_close.predict_proba(tsr_close.fit_transform(A2))
            max_index=probability_close[0].argmax(axis=0)
            print(probability_close[0])
            # if(probability_close[0][max_index]>=probability_threshold)and(max_index>=11)and(your_extra_judge(api,stock_code,pre_close,df_step,free_share)):
            if(probability_close[0][max_index]>=probability_threshold)and(max_index>=11):
                print('股票代码为',stock_code,'的股票当前还不赶紧买入更待何时!')
    except Exception as e:
        print(e)
        pass    
if __name__ == "__main__":
    real_time_predict_proba()