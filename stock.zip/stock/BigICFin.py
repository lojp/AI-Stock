# -*- coding: UTF-8 -*-
#1)不要问我tushare、pandas、pytdx、tslearn、pywt怎么安装这些问题,请自行百度； 一般pip install 即可。
#2)本程序需要300以上tushare积分才可运行,积分获取方法请参考https://tushare.pro/document/1?doc_id=13 ,当然你通过https://tushare.pro/register?reg=100017 注册tushare我会谢谢你的。
#3)这是预测概率的程序,策略原理请参考https://zhuanlan.zhihu.com/c_1100040485648797696 的一个基于机器学习的打板策略分享系列，欢迎在知乎交流。
import os
import tushare as ts
import pandas as pd
import numpy as np
import warnings
import time
from datetime import datetime
#忽略警告信息
warnings.filterwarnings("ignore")
#初始化当天日期
today=str(datetime.now().strftime('%Y%m%d'))

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
mypath = 'C:\\Private\\Analysis\\python\\mine\\stock\\'
os.chdir(mypath)

proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

ts_token='0c98ac2886e4331d7120a91573d3d025ba2eec7c96bfac77f9b7153d'
ts.set_token(ts_token)
pro = ts.pro_api()
# df = pro.top10_holders(ts_code='300456.SZ', start_date='20190901', end_date='20190930')
# print(df.dtypes)

# stock = ts.get_today_all()
# stock['date'] = today
# stock['ts_code'] = stock['code'].apply(lambda x: (x + '.SH') if x[0]== '6' else (x + '.SZ'))
# stock.to_csv('stock_data.csv',encoding = 'utf-8_sig')
    
def get_all_stock():
    stocks = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name,fullname,area,industry,list_date')
    return stocks

data_df = pd.DataFrame()           
if __name__ == "__main__":
    # 获取全部上市股票代码
    stocks = get_all_stock()
    # for i in range(len(stocks)):
    for i in range(5):
        stock = stocks.iloc[i]
        share_code = stock['ts_code']
        try:
            df = pro.top10_holders(ts_code=share_code, start_date='20200301', end_date='20200331')
            df['symbol']=stock['symbol']
            df['name']=stock['name']
            data_df = data_df.append(pd.DataFrame(df))
            print("get_top10_holders 获取成功，参数为：", share_code,i)            
        except:
            print("get_top10_holders 获取失败，参数为：", share_code,i,"XXX")
            time.sleep(0.5)
    # data_df.to_csv('topholders.CSV', encoding='utf-8',index=False)
    data_df.to_csv('topholders1.CSV', encoding='utf_8_sig',index=False)