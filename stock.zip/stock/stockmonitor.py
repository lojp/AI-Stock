# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
""" 

import os
import numpy as np
import operator
import time
from datetime import datetime
import pandas as pd
import tushare as ts
import matplotlib.pyplot as plt
import itchat
from tabulate import tabulate


proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy


# 打印tushare版本信息
# print(ts.__version__)

# 获取当日的日期信息
today = datetime.now().strftime('%Y%m%d')

# 文件常量
DATA = ''.join([today, '.csv'])
STOCK_BASICS = 'STOCK_BASICS.csv'


def monitor():
    '''监控程序'''

    # 获取收盘行情并保存
    data = ts.get_day_all()
    # data.to_csv(DATA, index=False)

    # 获取沪深上市公司基本情况并保存
    stock_basics = ts.get_stock_basics()
    # stock_basics.to_csv(STOCK_BASICS, index=False)

    # 合并信息
    df = pd.merge(data, stock_basics, how='inner')

    # 全市成交总额、成交量度、总市值
    amount = df['amount'].sum()
    volume = df['volume'].sum()
    abvalues = df['abvalues'].sum()

    db_all = ts.get_realtime_quotes(['sh','sz','cyb'])
    matrix =np.array(db_all[['code','price','pre_close']])
    a = list(map(float, matrix[:, 1]))
    b = list(map(float, matrix[:, 2]))
    c = list([str(round((x/y-1)*100,2))+'%' for x,y in zip(a, b)])
    d = np.insert(matrix, 2,c, axis=1)
    new_db_all = pd.DataFrame(d)
    new_db_all.columns =['code','price','change','pre_close']
    
    # 计算行业、地区平均涨跌幅
    industry = df[['industry','p_change']].groupby('industry').mean().sort_values(by='p_change')
    area = df[['area','p_change']].groupby('area').mean().sort_values(by='p_change')

    # 平均市盈率，市净率、换手率
    pe = df['pe'].mean()
    pb = df['pb'].mean()
    turnover = df['turnover'].mean()


    # 涨跌幅分析
    p_chg = np.array(df['p_change'])
    up = p_chg[p_chg > 0].size
    down = p_chg[p_chg < 0].size
    even = p_chg[p_chg == 0].size
    up_limit = p_chg[p_chg > 9.7].size
    down_limit = p_chg[p_chg < -9.7].size

    return {
            '上证综指':new_db_all.change[0],
            '深证综指':new_db_all.change[1],
            '创业板指数':new_db_all.change[2],
            # 'A股成交总额':amount,
            # 'A股成交总量':volume,
            # 'AB股总市值':round(abvalues,4),
            '平均涨幅居前的行业':industry.index[0] +', '+ industry.index[1] +', '+ industry.index[2],
            '平均跌幅居前的行业':industry.index[-1] +', '+ industry.index[-2] +', '+ industry.index[-3],
            '平均涨幅居前的地区':area.index[0]+', '+area.index[1]+', '+area.index[2],
            '平均跌幅居前的地区':area.index[-1]+', '+area.index[-2]+', '+area.index[-3],

            # '平均市盈率':round(pe,4),
            # '平均市净率':round(pb,4),
            # '平均换手率':round(turnover,4),

            'A股上涨家数':up,
            'A股平盘家数':even,
            'A股下跌家数':down,

            'A股涨停家数':up_limit,
            'A股跌停家数':down_limit
    }

def wechat(text,user):
    '''
    微信发送信息
    :param text: 发送内容
    :param user: 发送人
    :return:
    '''

    # 微信登录
    itchat.auto_login()
    itchat.send(text,toUserName=user)

def main():
    '''主函数入口'''
    info = monitor()

    print('收盘行情监控'.center(36,'-'))
    table = [[x,info.get(x)] for x in info.keys()]
    print(tabulate(table,tablefmt='grid'))

    print('END'.center(42,'-'))


if __name__ == '__main__':
    start = time.process_time()
    main()
    # monitor()
    print('程序耗时：{}'.format(time.process_time() - start))



