# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
"""
import numpy as np
import pandas as pd
import tushare as ts
import matplotlib.pyplot as plt
import os

proxy = 'fmcpr002-p1.nb.ford.com:83'
os.environ['http_proxy'] = proxy 
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy


ndf = ts.get_sina_dd('000931', date='2018-01-23', vol=400) #默认400手
# df = ndf.sort_values(['type', 'time'], ascending=[1, 1])
df = ndf.sort_values(['time'], ascending=1)
df['volume'] = df['volume'].astype(float)
df.ix[df.type== '卖盘', ['volume']] = -df.volume

df_group = pd.pivot_table(df,index=['time'], values=['volume'],aggfunc='sum').reset_index()

ax = df_group[['time','volume']].plot(kind='bar', title ="block trading data", figsize=(10, 6), fontsize=12)
ax.set_xlabel("time", fontsize=12)
ax.set_ylabel("volume", fontsize=12)
plt.show()