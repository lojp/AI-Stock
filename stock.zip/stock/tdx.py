# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017

@author: jluo27
""" 
import os
import time
import socket
import datetime
from pytdx.hq import TdxHq_API
socket.setdefaulttimeout(5)

# proxy = 'fmcpr002-p1.nb.ford.com:83'
# os.environ['http_proxy'] = proxy 
# os.environ['HTTP_PROXY'] = proxy
# os.environ['https_proxy'] = proxy
# os.environ['HTTPS_PROXY'] = proxy

# def ping(ip):
    # __time1 = datetime.datetime.now()
    # api = TdxHq_API()
    # try:
        # with api.connect(ip, 7709):
            # api.get_security_bars(9, 0, '000001', 0, 1)
        # return float(datetime.datetime.now() - x1)
    # except:
        # return datetime.timedelta(9, 9, 0)


# def select_best_ip():
    # listx = ['180.153.18.170', '180.153.18.171', '202.108.253.130', '202.108.253.131', '60.191.117.167', '115.238.56.198', '218.75.126.9', '115.238.90.165',
             # '124.160.88.183', '60.12.136.250', '218.108.98.244', '218.108.47.69', '14.17.75.71', '180.153.39.51']
    # data = [ping(x) for x in listx]
    # return listx[data.index(min(data))]

# if __name__ == "__main__":
    # select_best_ip()

standard_api = TdxHq_API(auto_retry=True, raise_exception=False)
while True:
    try:
        is_tdx_standard_connect = standard_api.connect('119.147.212.81', 7709, time_out=2)
    except Exception as e:
        logger.error('time out to connect to pytdx')
        logger.error(e)
        time.sleep(3)
        continue
        pass
    if is_tdx_standard_connect is not False:# 失败了返回False，成功了返回地址
        logger.info('connect to pytdx standard api successful')
        break
    else:
        time.sleep(3)
        continue
        pass
    pass