# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
   
    
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='Hyundai')
ttl_df = df.sort_values(by=['year'], ascending=1) 

x = ttl_df['year']    
xlab = ttl_df['year'].astype(str).str[2:]
y1 = ttl_df['sales']
y2 = ttl_df['share']


 
fig = plt.figure(figsize=(9,5))
ax1 = fig.add_subplot(111)
ax2 = ax1.twinx() 

#['bottom','right','top','left']
# for side in ['right','top','left']:
    # ax1.spines[side].set_visible(False)

# ax1.set_zorder(10)
# ax1.patch.set_visible(False)
    
line1 = ax1.plot(x, y1, 'bo-',markeredgewidth=3, markersize=6,label = u'销量')  
line2 = ax2.plot(x, y2, 'rx-',markeredgewidth=3, markersize=6,label = u'份额')

# ax1.yaxis.tick_right()
# ax2.yaxis.tick_left()
ax1.set_xticks(x)
ax1.set_xticklabels(xlab, rotation=0) ##
ax1.set_title('1986-2017现代在美国市场的销量和市场份额', fontproperties=zhfont2,size=12,fontweight='bold')
# fig.subplots_adjust(top=0.9, bottom=0.15, right=0.85, left=0.15)


lns = line1+line2
labs = [l.get_label() for l in lns]
ax1.legend(lns, labs, loc=0,prop=zhfont1)

ax1.annotate('现代优势', xy=(1998.2, 120000), xytext=(1998, 250000),
            size=12, ha='right', va="center",
            arrowprops=dict(arrowstyle="->",connectionstyle="arc3,rad=-0.2"),
            horizontalalignment='right',
            verticalalignment='top',
            fontproperties=zhfont1)


plt.figtext(0.05, 0.0, '数据来源：MarkLines全球汽车产业平台', ha='left', va = 'bottom',fontproperties=zhfont1,size=10)
fig.set_tight_layout(True) 
fig.savefig('C:/Private/Analysis/python/mine/paper/USAhdsales.png')  
plt.show()


