# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
    
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='cpu_h')
ttl_df = df.sort_values(by=['year'], ascending=1) 
    

xlab = ttl_df['year']
x = range(len(xlab))
y1 = ttl_df['rpu']


fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 6
fig_size[1] = 4
plt.rcParams["figure.figsize"] = fig_size



fig = plt.figure(figsize=(8,4))
ax1 = fig.add_subplot(111)


ax1.bar(x, y1, 0.5 , color='gray',label = 'Repairs per Unit')  


# ax1.yaxis.tick_right()
# ax2.yaxis.tick_left()
ax1.set_xticks(x)
ax1.set_xticklabels(xlab, rotation=0) ##
ax1.set_title('F韩国市场质保期内车辆维修次数', fontproperties=zhfont2,size=12,fontweight='bold')
# fig.subplots_adjust(top=0.9, bottom=0.15, right=0.85, left=0.15)
plt.figtext(0.05, 0.0, '数据来源：F公司内部数据', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
fig.tight_layout()
# ax1.set_xlabel('数据来源：F公司内部数据', fontproperties=zhfont1,size=8)
fig.savefig('C:/Private/Analysis/python/mine/paper/kor_cpu.png')  
plt.show()


