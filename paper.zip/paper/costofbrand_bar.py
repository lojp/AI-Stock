# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
    
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='cost')
ttl_df = df.sort_values(by=['year'], ascending=1) 
    

# xlab = ttl_df['month']
x = ttl_df['year']
y1 = ttl_df['Hyundai']  #ttl_df['VW']
y2 = ttl_df['Toyota']
y3 = ttl_df['Ford']
y4 = ttl_df['GM']
y5 = ttl_df['VW']
y6 = ttl_df['BMW']
y7 = ttl_df['Tesla']

fig = plt.figure(figsize=(8,5))
ax1 = fig.add_subplot(111)
width = 0.2

# line1 = ax1.bar(x - 3*width, y1, color='y',width= 0.2,label = 'Hyundai')  
# line4 = ax1.bar(x - 2*width, y2, color='c',width= 0.2,label = 'Toyota') 
# line2 = ax1.bar(x - width, y3, color='b',width= 0.2,label = 'Ford') 
# line3 = ax1.bar(x, y4, color='r',width= 0.2,label = 'GM') 
# line5 = ax1.bar(x + width, y5, color='k',width= 0.2,label = 'VW') 
# line6 = ax1.bar(x + 2*width, y6, color='m',width= 0.2,label = 'BMW') 
# line7 = ax1.bar(x + 3*width, y7, color='g',width= 0.2,label = 'Tesla') 

line1 = ax1.bar(x - 2*width, y1, color='y',width= 0.15,label = 'Hyundai')  
line2 = ax1.bar(x- width, y3, color='b',width= 0.15,label = 'Ford') 
line4 = ax1.bar(x , y2, color='m',width= 0.15,label = 'Toyota') 
line5 = ax1.bar(x + width, y5, color='gray',width= 0.15,label = 'VW')
line6 = ax1.bar(x + 2*width, y6, color='c',width= 0.15,label = 'BMW')  
line7 = ax1.bar(x + 3*width, y7, color='r',width= 0.15,label = 'Tesla') 


ax1.set_xticks(x)
ax1.set_xticklabels(x, rotation=0) ##
ax1.set_title('美国每辆新车质保成本(美元)', fontproperties=zhfont2,size=12,fontweight='bold')
# fig.subplots_adjust(top=0.9, bottom=0.15, right=0.85, left=0.15)


# lns = line1+line2+line3+line4+line5+line6+line7
# labs = [l.get_label() for l in lns]
# ax1.legend(lns, labs, loc=0)
ax1.legend()
plt.figtext(0.05, 0.0, '数据来源：Warranty Week网站', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
# ax1.set_xlabel('数据来源：Warranty Week网站', fontproperties=zhfont1,size=8)
#Source: Warranty Report
fig.set_tight_layout(True)
fig.savefig('C:/Users/jluo27/Desktop/costbybrand.png')  
plt.show()


