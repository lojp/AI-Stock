# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
   
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='q1')
ttl_df = df.sort_values(by=['mix'], ascending=1) 
    


x = ttl_df['type']
y1 = ttl_df['mix']

fig = plt.figure(figsize=(5,5))
ax1 = fig.add_subplot(111)

def autopct_more_than_1(pct):
    return ('%.0f%%' % pct) if pct > 0.01 else ''  ###remove little data
    
    
pie = ax1.pie(y1, labels=x, autopct=autopct_more_than_1,pctdistance=1, labeldistance=0.6)


for font in pie[1]:
    font.set_fontproperties(zhfont1)

# ax1.set_title('组织内部是否有质保对标分析？', fontproperties=zhfont2,size=12)
plt.xlabel('数据来源：Oracle和Tata的美国制造企业的调查报告', fontproperties=zhfont1,size=10)
fig.tight_layout()
fig.savefig('C:/Private/Analysis/python/mine/paper/q1.png')  
plt.show()
