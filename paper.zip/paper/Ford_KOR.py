# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
   
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='KOR')

# df = df[df['year'] <2010]
ttl_df = df.sort_values(by=['year'], ascending=1) 
    

x = ttl_df['year']
y1 = ttl_df['TTL']
y2 = ttl_df['Benz']
y3 = ttl_df['BMW']



 
fig = plt.figure(figsize=(8,4))
ax1 = fig.add_subplot(111)
# ax2 = ax1.twinx() 

#['bottom','right','top','left']
# for side in ['right','top','left']:
    # ax1.spines[side].set_visible(False)

# ax1.set_zorder(10)
# ax1.patch.set_visible(False)
    
line1 = ax1.plot(x, y1, 'bo-',markeredgewidth=3, markersize=6,label = 'F')  
line2 = ax1.plot(x, y2, 'go--',markeredgewidth=3, markersize=6,label = 'Benz') 
line3 = ax1.plot(x, y3, 'rx--',markeredgewidth=3, markersize=6,label = 'BMW')
# line4 = ax2.plot(x, y4, 'gx-',markeredgewidth=3, markersize=6,label = 'Sales for L in China market')

# ax1.yaxis.tick_right()
# ax2.yaxis.tick_left()
ax1.set_xticks(x)
ax1.set_xticklabels(x, rotation=0) ##
# ax1.set_title('2001-2017韩国市场的进口车销量', fontproperties=zhfont2,size=12,fontweight='bold')
# ax1.set_title('2001-2009韩国市场的进口车销量', fontproperties=zhfont2,size=12,fontweight='bold')
# fig.subplots_adjust(top=0.9, bottom=0.15, right=0.85, left=0.15)


lns = line1+line2+line3
labs = [l.get_label() for l in lns]
ax1.legend(lns, labs, loc=0)
# ax1.set_xlabel('数据来源：韩国进口汽车协会(KAIDA)', fontproperties=zhfont1,size=8)
plt.figtext(0.05, 0.0, '数据来源：韩国进口汽车协会(KAIDA)', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
fig.tight_layout()
fig.savefig('C:/Private/Analysis/python/mine/paper/ford_chnkor.png')  
# fig.savefig('C:/Private/Analysis/python/mine/paper/ford_chnkor2.png')  
plt.show()


