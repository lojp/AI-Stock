import matplotlib.pyplot as plt
import numpy as np
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
#here's our data to plot, all normal Python lists
x = [1, 2, 3, 4, 5,6]
y = [1, 2, 3, 4, 5,6]

labals = [1.5, 2.5, 3.5, 4.5, 5.5]

intensity = [
    [1, 2, 2, 3, 3, 3],
    [2, 2, 3, 3, 3, 4],
    [2, 3, 3, 3, 4, 4],
    [3, 3, 3, 4, 4, 5],
    [3, 3, 4, 4, 5, 5],
    [3, 4, 4, 5, 5, 5]
]





#setup the 2D grid with Numpy
x, y = np.meshgrid(x, y)
intensity = np.array(intensity)

fig, ax = plt.subplots(1, 1)
plt.xlabel('<-- 可能性 -->',fontproperties=zhfont1,size=12)
plt.ylabel('<-- 严重性 -->',fontproperties=zhfont1,size=12)
# ax.set_title('风险评估矩阵', fontproperties=zhfont2,size=12)
#now just plug the data into pcolormesh, it's that easy!
ax.pcolormesh(x, y, intensity,cmap='YlOrRd')

#+1 if int((labals[i]+labals[j])/2.05)<3 else int((labals[i]+labals[j])/2.05)

for i in range(len(labals)):
    for j in range(len(labals)):
        plt.text(labals[i], labals[j], round((labals[i]+labals[j])/2.35), 
             horizontalalignment='center',
             verticalalignment='center')




plt.xticks(labals,
           ["低", "较低", "中", "较高", "高"],fontproperties=zhfont1)
# plt.colorbar() #need a colorbar to show the intensity scale
plt.yticks(labals,
           ["低", "较低", "中", "较高", "高"],fontproperties=zhfont1)

ax.set_yticks([1, 2, 3, 4, 5, 6], minor=True)
ax.set_xticks([1, 2, 3, 4, 5, 6], minor=True)              
ax.grid(True, color="k",lw=0.5, which='minor')   
fig.savefig('C:/Private/Analysis/python/mine/paper/heat.png')          
plt.show() #boom