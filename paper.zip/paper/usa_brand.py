# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')


# df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='Period')
# l = list(df.Roadside)  #Powertrain,Rust,Roadside
# k = [i.split('/', 1)[1] for i in l]
# print(k)

# nameL='Powertrain'
# brand = ['Audi', 'BMW', 'Benz', 'VW', 'Fiat', 
    # 'Buick', 'Cadillac', 'Chevrolet', 'GMC', 'Ford', 
    # 'Lincoln', 'Toyota', 'Lexus', 'Honda', 'Nissan', 
    # 'Hyundai', 'Kia', 'Land Rover']
# year =[4,4,4,5,4,6,6,5,5,5, 6, 5, 6, 5, 5, 10, 10, 4]
# mile =[50000, 50000, 50000, 60000, 50000, 70000, 70000, 100000, 100000, 60000, 70000, 60000, 70000, 60000, 60000, 100000, 100000, 50000]



# nameL='Rust&Corrosion'
# brand = ['Audi', 'BMW', 'Benz', 'VW', 'Fiat', 
    # 'Buick', 'Cadillac', 'Chevrolet', 'GMC', 'Ford', 
    # 'Lincoln', 'Toyota', 'Lexus', 'Honda', 'Nissan', 
    # 'Hyundai', 'Kia', 'Land Rover']
# year =[12, 12, 4, 12, 5, 6, 4, 6, 6, 5, 5, 5, 6, 5, 5, 7, 5, 6]
# mile =[0, 0, 50000, 0, 100000, 100000, 50000, 100000, 100000, 0, 0, 0,0 , 0, 0, 0, 100000,0 ]

# nameL='Roadside Assistance'
# brand = ['Audi', 'BMW', 'Benz', 'VW', 'Fiat', 
    # 'Buick', 'Cadillac', 'Chevrolet', 'GMC', 'Ford', 
    # 'Lincoln', 'Toyota', 'Lexus', 'Nissan', 
    # 'Hyundai', 'Kia', 'Land Rover', 'Tesla']
# year =[4, 4, 7, 4, 4, 6, 6, 5, 5, 5, 6, 3, 4, 3, 5, 5, 4, 4]
# mile =[0, 0, 0, 36000, 0, 70000, 70000, 100000, 100000, 60000, 70000, 25000, 0, 36000, 0, 60000, 50000, 50000]


nameL='Basic'
brand = ['Audi', 'BMW', 'Benz', 'VW', 'Fiat', 
    'Buick', 'Cadillac', 'Chevrolet', 'GMC', 'Ford', 
    'Lincoln', 'Toyota', 'Lexus', 'Honda', 'Nissan', 
    'Hyundai', 'Kia', 'Land Rover', 'Tesla']
year =[4, 4, 4, 3, 4, 4, 4, 3, 3, 3, 4, 3, 4, 3, 3, 5, 5, 4, 4]
mile =[50000, 50000, 50000, 36000, 50000, 50000, 50000, 36000, 36000, 36000, 50000, 36000, 50000, 36000, 36000, 60000, 60000, 50000, 50000]


# print(len(brand),len(year),len(mile))
ttl_df = pd.DataFrame(
    {'brand': brand,
     'year': year,
     'mile': mile
    })

   
ttl_df['m_']  =  np.where(ttl_df['mile'] ==0,1000009,ttl_df['mile'])
ttl_df = ttl_df.sort_values(by=['year','m_'], ascending=[1,1])   
# print(ttl_df)


ylab = ttl_df['brand']
y = range(len(ylab))
x1 = ttl_df['year']
x2 = ttl_df['mile']
# y = range(20)
# x1 = range(20)
# x2 = range(0, 200, 10)


fig, axes = plt.subplots(ncols=2, sharey=True)
# plt.suptitle('美国市场各品牌的道路救援质保政策',fontproperties=zhfont2, fontsize=12)   #基本,发动机,道路救援,漆面

axes[0].barh(y, x1, align='center', color='gray')
axes[0].set_xlabel('年限',fontproperties=zhfont1)
axes[0].invert_xaxis()
axes[0].set_yticks([])
axes[0].spines['top'].set_visible(False)  
axes[0].spines['right'].set_visible(False)
# axes[0].spines['bottom'].set_visible(False)  
axes[0].spines['left'].set_visible(False)  


axes[1].barh(y, x2, align='center', color='gray')
axes[1].set_xlabel('里程(公里)',fontproperties=zhfont1)
axes[1].spines['top'].set_visible(False)  
axes[1].spines['right'].set_visible(False)
# axes[1].spines['bottom'].set_visible(False)  
axes[1].spines['left'].set_visible(False) 

# axes[0].set_yticklabels(ylab,fontsize=8,ha='center')
# axes[0].yaxis.tick_right()

# for ax in axes.flat:
    # ax.margins(0.03)
    # ax.grid(True)

fig.tight_layout(rect=[0, 0.03, 1, 0.95])
fig.subplots_adjust(wspace=0.35)

for y, text in zip(range(len(ylab)),
                         [x  for x in list(ylab)]):
    plt.text(-11000, y-0.2, text,ha='center')   ##-19000,-19000,-19000,-11000
    
plt.figtext(0.05, 0.01, '数据来源：论文作者根据各品牌官方网站数据整理', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
fig.savefig('C:/Private/Analysis/python/mine/paper/usabrandpolicy' + nameL +'.png')  

plt.show()