import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from matplotlib.font_manager import FontProperties
font1 = FontProperties(fname=r"C:\\Windows\\Fonts\\simsun.ttc", size=10)
font2 = FontProperties(fname=r"C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC", size=12)


def money(x, pos):
    'The two args are the value and tick position'
    return "${}M".format(int(x/1000000))
formatter = FuncFormatter(money)


index = ['Baseline\nWarranty','Admin\ncost Reduction','Supplier\nRecovery','Detection\nand Correction','Re-pricing','Lower Cost\nof Fraud']
chnindex = [r'目标质保费用',r'行政手段',r'供应商索赔',r'提前侦探',r'降价',r'稽查',r'新质保费用']
data = {'amount': [250000000,-3000000,-19000000,-30000000,-15000000,-5000000]}


trans = pd.DataFrame(data=data,index=index)
transchn = pd.DataFrame(index=chnindex)
blank = trans.amount.cumsum().shift(1).fillna(0)

total = trans.sum().amount
trans.loc["New\nWarranty"]= total
blank.loc["New\nWarranty"] = total


step = blank.reset_index(drop=True).repeat(3).shift(-1)
step[1::3] = np.nan


blank.loc["New\nWarranty"] = 0

my_plot = trans.plot(kind='bar', color='gray',stacked=True, bottom=blank,legend=None, figsize=(8,4.5))
my_plot.plot(step.index, step.values,'r--')
# my_plot.set_title(u'F公司质保管理',fontproperties=font2)

#Format the axis for dollars
my_plot.yaxis.set_major_formatter(formatter)

#Get the y-axis position for the labels
y_height = trans.amount.cumsum().shift(1).fillna(0)

#Get an offset so labels don't sit right on top of the bar
max = trans.max()
neg_offset = max / 25
pos_offset = max / 50
plot_offset = int(max / 13)

#Start label loop
loop = 0
for index, row in trans.iterrows():
    # For the last item in the list, we don't want to double count
    if row['amount'] == total:
        y = y_height[loop]
    else:
        y = y_height[loop] + row['amount']
    # Determine if we want a neg or pos offset
    if row['amount'] > 0:
        y += pos_offset
    else:
        y -= neg_offset
    my_plot.annotate("{}M".format(row['amount']/1000000),(loop,y),ha="center")
    loop+=1

#Scale up the y axis so there is room for the labels
my_plot.set_ylim(0,blank.max()+3*int(plot_offset))
#Rotate the labels
my_plot.set_xticklabels(transchn.index,rotation=0,multialignment='center', fontproperties=font1,size=10)

my_plot.set_xlabel("数据来源：F公司内部数据",fontproperties=font1,size=10)
# my_plot.text(0,0,"数据来源：F公司内部数据")
# my_plot.figtext(0.3, 0.1, '数据来源：F公司内部数据', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
my_plot.get_figure().savefig("C:/Private/Analysis/python/mine/paper/managewaterfull.png",dpi=200,bbox_inches='tight')
plt.show()