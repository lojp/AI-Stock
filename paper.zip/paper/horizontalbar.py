# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd


# df = pd.read_excel('C:/Users/jluo27/Desktop/paper/Chart.xlsx',sheet_name='Period')
# l = list(df.Basic)
# k = [i.split('/', 1)[1] for i in l]
# print(k)

brand = ['Audi', 'BMW', 'Benz', 'VW', 'Fiat', 
    'Buick', 'Cadillac', 'Chevrolet', 'GMC', 'Ford', 
    'Lincoln', 'Toyota', 'Lexus', 'Honda', 'Nissan', 
    'Hyundai', 'Kia', 'Land Rover', 'Tesla']

year =[4, 4, 4, 3, 4, 4, 4, 3, 3, 3, 4, 3, 4, 3, 3, 5, 5, 4, 4]
mile =[50000, 50000, 50000, 36000, 50000, 50000, 50000, 36000, 36000, 36000, 50000, 36000, 50000, 36000, 36000, 60000, 60000, 50000, 50000]

ttl_df = pd.DataFrame(
    {'brand': brand,
     'year': year,
     'mile': mile
    })

ttl_df = ttl_df.sort_values(by=['year'], ascending=1) 
    
# print(ttl_df.head(5))


ylab = ttl_df['brand']
y = range(len(ylab))
x1 = ttl_df['year']
x2 = ttl_df['mile']
# y = range(20)
# x1 = range(20)
# x2 = range(0, 200, 10)

fig, axes = plt.subplots(ncols=2, sharey=True)
axes[0].barh(y, x1, align='center', color='gray')
axes[0].set(title='Number of Years')
axes[1].barh(y, x2, align='center', color='gray')
axes[1].set(title='Number of Miles')
axes[0].invert_xaxis()
axes[0].set_yticks(y)
axes[0].set_yticklabels(ylab,fontsize=8)
axes[0].yaxis.tick_right()

# for ax in axes.flat:
    # ax.margins(0.03)
    # ax.grid(True)

fig.tight_layout()
fig.subplots_adjust(wspace=0.25)
plt.show()