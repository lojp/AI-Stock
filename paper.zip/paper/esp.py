# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
   
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='esp')
ttl_df = df.sort_values(by=['cost'], ascending=1) 
    


x = ttl_df['market']
y1 = ttl_df['cost']

fig = plt.figure(figsize=(5,5))
ax1 = fig.add_subplot(111)

def autopct_more_than_1(pct):
    return ('%.0f%%' % pct) if pct > 0.01 else ''  ###remove little data
    
    
pie = ax1.pie(y1, labels=x, autopct=autopct_more_than_1,pctdistance=1, labeldistance=0.6)


for font in pie[1]:
    font.set_fontproperties(zhfont1)

# ax1.set_title('2017亚太地区有偿延保收入占比', fontproperties=zhfont2,size=12)
# plt.figtext(0.3, 0.1, '数据来源：F公司内部数据', ha='left', va = 'bottom',fontproperties=zhfont1,size=8) 
plt.xlabel('数据来源：F公司内部数据', fontproperties=zhfont1,size=10)
fig.tight_layout()
fig.savefig('C:/Private/Analysis/python/mine/paper/esp.png')  
plt.show()
