# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')

     
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='recall')
ttl_df = df.sort_values(by=['year'], ascending=1) 
    

x = ttl_df['year']
y1 = ttl_df['car']
y2 = ttl_df['time']

fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 8
fig_size[1] = 4.5
plt.rcParams["figure.figsize"] = fig_size

 
fig = plt.figure()
plt.gca().relim()
ax1 = fig.add_subplot(111)
ax2 = ax1.twinx() 

for side in ['right','top','left']:
    ax1.spines[side].set_visible(False)
    ax2.spines[side].set_visible(False)

ax1.xaxis.set_ticks_position('none')
ax1.yaxis.set_ticks_position('none')
ax1.xaxis.set_ticklabels([])
ax1.yaxis.set_ticklabels([])
ax1.xaxis.set_ticks([])
ax1.yaxis.set_ticks([])

ax2.xaxis.set_ticks_position('none')
ax2.yaxis.set_ticks_position('none')
ax2.xaxis.set_ticklabels([])
ax2.yaxis.set_ticklabels([])
ax2.xaxis.set_ticks([])
ax2.yaxis.set_ticks([])


pbar = ax1.bar(x, y1,color='gray',linewidth=0.5, edgecolor = "none",label = '车辆')  
pplot, = ax2.plot(x, y2, 'ro-',markeredgewidth=3, markersize=8,label = '次数')

ax1.yaxis.tick_right()
ax2.yaxis.tick_left()
ax1.set_xticks(x)
ax1.set_xticklabels(x, rotation=90) ##
ax1.set_title('2004-2017年汽车召回次数和数量情况', fontproperties=zhfont2,size=12)
fig.subplots_adjust(top=0.9, bottom=0.15, right=0.85, left=0.15)


# handles = [pplot,pbar]
# labels  = [pplot.get_label(),pbar.get_label()]
# ax1.legend(handles,labels)


for a,b,c in zip(x,y2,y1):
    ax2.text(a, b+0.05, '%.0f' % b, ha='center', va= 'bottom',fontsize=7)
    ax1.text(a, c/2, "{}万".format(int(c/10000)), ha='center', va= 'bottom', fontproperties=zhfont2,fontsize=7)

# ax1.set_xlabel('数据来源：国家质检总局', fontproperties=zhfont1,size=8)
plt.figtext(0.05, 0.0, '数据来源：国家质检总局', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
fig.set_tight_layout(True) 
fig.savefig('C:/Private/Analysis/python/mine/paper/CHNrecall.png')  
plt.show()


