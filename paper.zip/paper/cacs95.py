# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
    
    
fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 6
fig_size[1] = 3.5
plt.rcParams["figure.figsize"] = fig_size
    
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='CS95')
ttl_df = df.sort_values(by=['month'], ascending=1) 
    

xlab = ttl_df['month'].str[2:]
x = range(len(xlab))
y1 = ttl_df['sales']

fig = plt.figure()
ax1 = fig.add_subplot(111)

ax1.bar(x, y1,color='gray',width= 0.5,label ='sales')  


# ax1.yaxis.tick_right()
# ax2.yaxis.tick_left()
ax1.set_xticks(x)
ax1.set_xticklabels(xlab, rotation=0) ##
ax1.set_title('长安CS95上市销量', fontproperties=zhfont2,size=12,fontweight='bold')
# fig.subplots_adjust(top=0.9, bottom=0.15, right=0.85, left=0.15)

# ax1.set_xlabel('数据来源：中国乘联会', fontproperties=zhfont1,size=8)

# fig.tight_layout()
plt.figtext(0.05, 0.01, '数据来源：中国乘联会', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
fig.set_tight_layout(True) 
fig.savefig('C:/Private/Analysis/python/mine/paper/cacs95.png')  
plt.show()


