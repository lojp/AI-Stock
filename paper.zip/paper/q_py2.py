# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
    
    
fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 6
fig_size[1] = 4
plt.rcParams["figure.figsize"] = fig_size
    

index = [r'客户满意度',r'行业标准',r'竞争对手提供',r'促进售后销售零部件']
data = {'mix': [0.77,0.58,0.27,0.26]}


df = pd.DataFrame(data=data,index=index)
ttl_df = df.sort_values(by=['mix'], ascending=0) 
    

xlab = ttl_df.index
x = range(len(xlab))
y1 = ttl_df['mix']


fig = plt.figure()
ax1 = fig.add_subplot(111)

ax1.bar(x, y1,color='b',width= 0.5,label ='')  



# ax1.yaxis.tick_right()
# ax2.yaxis.tick_left()
ax1.set_xticks(x)
ax1.set_xticklabels(xlab, rotation=0,fontproperties=zhfont1) ##
ax1.set_title('为什么企业提供质保？', fontproperties=zhfont2,size=12,fontweight='bold')
# fig.subplots_adjust(top=0.9, bottom=0.15, right=0.85, left=0.15)

# ax1.set_xlabel('数据来源：Oracle和Tata的美国制造企业的调查报告', fontproperties=zhfont1,size=8)
for side in ['right','top','left']:
    ax1.spines[side].set_visible(False)

# ax1.xaxis.set_ticks_position('none')
ax1.yaxis.set_ticks_position('none')
# ax1.xaxis.set_ticklabels([])
ax1.yaxis.set_ticklabels([])
# ax1.xaxis.set_ticks([])
ax1.yaxis.set_ticks([])

for a,b in zip(x,y1):
    ax1.text(a, b+0.005, '%.0f%%' % int(b*100), ha='center', va= 'bottom',fontsize=12)

plt.figtext(0.05, 0.0, '数据来源：Oracle和Tata的美国制造企业的调查报告', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
fig.tight_layout()
fig.savefig('C:/Private/Analysis/python/mine/paper/q2.png')  
plt.show()


