# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
    
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='cost')
ttl_df = df[df['year']>2011].sort_values(by=['year'], ascending=1) 
    

# xlab = ttl_df['month']
x = ttl_df['year']
y1 = ttl_df['Tesla']  #ttl_df['VW']
y2 = ttl_df['GM']
y3 = ttl_df['Ford']


index = np.arange(len(x)) 
bar_width = 0.15 
alpha_value = 1
fig,ax = plt.subplots()  
plt.grid(which='major',axis='y')


ax1= plt.bar(index - bar_width, y3, bar_width, color='b',hatch='-',label='F')
ax2= plt.bar(index, y2, bar_width, color='r',hatch='//',label='GM')
ax3= plt.bar(index + bar_width, y1, bar_width, color='g',hatch='\\',label='Tesla')


plt.ylim(ymax=4000)
plt.legend(ncol=3)
# plt.xlabel('Group')    
# plt.ylabel('Scores')    
plt.title('美国每辆新车质保成本(美元)', fontproperties=zhfont2,size=12,fontweight='bold')    
plt.xticks(index + bar_width, x)     
# plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05), ncol=6)


plt.figtext(0.05, 0, '数据来源：Warranty Week网站', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
#Source: Warranty Report
fig.set_tight_layout(True)
fig.savefig('C:/Private/Analysis/python/mine/paper/UScostbybrand.png')  
plt.show()


