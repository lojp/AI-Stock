# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')
    
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='xrv')
ttl_df = df.sort_values(by=['month'], ascending=1) 
    

xlab = ttl_df['month']
x = range(len(xlab))
y1 = ttl_df['qty']



fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 6
fig_size[1] = 4
plt.rcParams["figure.figsize"] = fig_size

fig = plt.figure(figsize=(6,3))
ax1 = fig.add_subplot(111)


ax1.plot(x, y1, 'ro-',markeredgewidth=3, markersize=6)  


# ax1.yaxis.tick_right()
# ax2.yaxis.tick_left()
ax1.set_xticks(x)
ax1.set_xticklabels(xlab, rotation=0) ##
# ax1.set_title('丰田XRV发动机机油投诉量', fontproperties=zhfont2,size=12)
# fig.subplots_adjust(top=0.9, bottom=0.15, right=0.85, left=0.15)

ax1.annotate('召回延保声明', xy=(9, 200), xytext=(10, 500),
            size=8, ha='right', va="center",
            arrowprops=dict(arrowstyle="->",connectionstyle="arc3,rad=-0.2"),
            horizontalalignment='right',
            verticalalignment='top',
            fontproperties=zhfont1)

# ax1.set_xlabel('数据来源：车质网', fontproperties=zhfont1)
plt.figtext(0.05, 0.0, '数据来源：车质网', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
fig.tight_layout()
fig.savefig('C:/Private/Analysis/python/mine/paper/xrv.png')  
plt.show()


