# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: jluo27
"""
from scipy import stats # Import the scipy.stats module
from scipy.optimize import curve_fit # Import the curve fitting module
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from scipy import asarray as ar,exp
import scipy.special as sp
import math
import operator
from distcdf import *
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')

year = 2017
# df = pd.read_csv('C:/jluo/Export/TISREPtest.CSV', encoding='utf-8')
df = pd.read_csv('C:/jluo/Export/TISREPTT.CSV', encoding='utf-8')
ndf = df[(df['MODEL YEAR'] == year) & (df['PART NUM BASE (CAUSL)'] == 'TOTAL') & (df['PROD_MONTH'].isnull())]

N = 14
ydata = list(ndf['R1000'][1:N+1]/1000)
x = ar(range(1,N+1))
y = ar(ydata)
xx = ar(range(1,37))
dists = ['正态分布','指数分布','对数正态分布','威尔布分布']
distnames = ['Normal_cdf','Exponetial_cdf','Lognormal_cdf','Weibull_cdf']

def r(x,y,z):
    ss_res = np.sum(x**2)
    ss_tot = np.sum((y-np.mean(y))**2)
    return 1 - (ss_res / ss_tot),z

if max(y) > 0.03: 	
    poptw,pcovw =  curve_fit(weibull_cdf,x,y, bounds=(0, [5, 100]))
    popte,pcove =  curve_fit(exponetial_cdf,x,y, bounds=(0, [5, 100]))
    poptn,pcovn =  curve_fit(normal_cdf,x,y)
    poptl,pcovl =  curve_fit(lognormal_cdf,x,y)

    resiw = y- weibull_cdf(x, *poptw)
    resie = y- exponetial_cdf(x, *popte)
    resin = y- normal_cdf(x, *poptn)
    resil = y- lognormal_cdf(x, *poptl)

    ttw = weibull_cdf(36, *poptw)
    tte = exponetial_cdf(36, *popte)
    ttn = normal_cdf(36, *poptn)
    ttl = lognormal_cdf(36, *poptl)

    lt_r  = []
    lt_r.append(r(resiw,y,ttw))
    lt_r.append(r(resie,y,tte))
    lt_r.append(r(resin,y,ttn))
    lt_r.append(r(resil,y,ttl))
    r_squared,ttvalue = zip(*lt_r)

    index, value = max(enumerate(r_squared), key=operator.itemgetter(1))
    ind, val = max(enumerate(ttvalue), key=operator.itemgetter(1))

    # plt.style.use('ggplot')
    fig, axs = plt.subplots(2,2, figsize=(11, 7))
    fig.subplots_adjust(hspace = .3, wspace=.15)
    axs = axs.ravel()
    plt.suptitle('可靠性分析: 各模型的累积分布函数', fontproperties=zhfont2,fontsize=20)
    # plt.suptitle('The Best Distribution is ' + dists[index] + '\n' + 'F(36)=' + str(round(ttvalue[index],4)), fontsize=16)   #显示best
    axs[0].plot(xx,normal_cdf(xx,*poptn),'r--',label='拟合')
    axs[1].plot(xx,exponetial_cdf(xx,*popte),'r--',label='拟合')
    axs[2].plot(xx,lognormal_cdf(xx,*poptl),'r--',label='拟合')
    axs[3].plot(xx,weibull_cdf(xx,*poptw),'r--',label='拟合')
    
    for i in range(4):
        axs[i].step(x,y,'b-',where='mid',label='实际')
        axs[i].set_title(dists[i], fontproperties=zhfont2)
        axs[i].set_xlabel('时间', fontproperties=zhfont1,fontsize=7)
        axs[i].set_ylabel('累计失效率', fontproperties=zhfont1,fontsize=7)
        axs[i].set_ylim([0, round(val*5)/5])
        axs[i].yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.0%}'.format(y))) 
        axs[i].text(30, val*0.05, r'$R^{2} = $' + str(round(r_squared[i],4)))
        axs[i].legend(loc="upper left",prop=zhfont1)
        # if i == index:  #加沟
            # axs[i].text(30, 0.6, r'$\checkmark$',fontsize=32,color='red')
            # axs[i].text(-1, val*0.95, round(ttvalue[i],4),color='red')
            # axs[i].arrow(36, ttvalue[i], -37, 0, color='k',lw=0.3,ls='--')
    # plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3,ncol=2, borderaxespad=0.)
    plt.figtext(0.1, 0.0, '数据来源：F公司内部数据', ha='left', va = 'bottom',fontproperties=zhfont2,size=10) 
    # fig.tight_layout()
    fig.savefig('C:/Private/Analysis/python/mine/paper/cdf4chart.png')
    plt.show()	

    # fcrpt = pd.DataFrame() 
    # if index ==0:
        # fcrpt['Forecast_R1000'] = (weibull_cdf(xx,*poptw)*1000).tolist()
    # elif index == 1:
    	# fcrpt['Forecast_R1000'] = (exponetial_cdf(xx,*popte)*1000).tolist()
    # elif index == 2:
    	# fcrpt['Forecast_R1000'] = (normal_cdf(xx,*poptn)*1000).tolist()
    # else:
    	# fcrpt['Forecast_R1000'] = (lognormal_cdf(xx,*poptl)*1000).tolist()
    # fcrpt['TIS'] = xx.tolist()
    # fcrpt['MODEL YEAR'] = year
    # rpt = pd.merge(fcrpt, ndf[['MODEL YEAR','TIS','R1000','VEHICLES']],how='outer', on=['MODEL YEAR','TIS'])
    # rpt.sort_values(by=['TIS']).to_csv('C:/jluo/Export/rpt_tis.CSV', encoding='utf-8',index=False,columns=['MODEL YEAR','TIS','VEHICLES','R1000','Forecast_R1000'])

# else:
    # plt.step(x,y,'b-',where='mid')
    # plt.ylim([0, 0.2])
    # plt.xlim([0, 36])
    # plt.show()

# for i in range(4):
# popt,pcov =  curve_fit(d[0],x,y, bounds=(0, [5, 100]))
# resi = y- d[0](x, *popt)
# ttw = d[0](36, *popt)
# print(d[0])