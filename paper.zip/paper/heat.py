# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import numpy as np

a = np.random.random((6, 6))

# correlations = data.corr()  #计算变量之间的相关系数矩阵
# plot correlation matrix
fig = plt.figure() #调用figure创建一个绘图对象
ax = fig.add_subplot(111)
cax = ax.matshow(a, cmap='hot', interpolation='nearest')  #绘制热力图，从-1到1
fig.colorbar(cax)  #将matshow生成热力图设置为颜色渐变条
ticks = np.arange(1,6,1) #生成0-9，步长为1
ax.set_xticks(ticks)  #生成刻度
ax.set_yticks(ticks)
# ax.set_xticklabels(names) #生成x轴标签
# ax.set_yticklabels(names)

fig.savefig('C:/Private/Analysis/python/mine/paper/heat.png') 
plt.show()