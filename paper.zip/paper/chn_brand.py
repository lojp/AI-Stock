# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')

     
df = pd.read_excel('C:/Private/Analysis/python/mine/paper/Chart.xlsx',sheet_name='CHINA')
ttl_df = df.sort_values(by=['Year','Mile'], ascending=[1,1]) 
    

nameL='Basic'
ylab = ttl_df['Brand']
y = range(len(ylab))
x1 = ttl_df['Year']
x2 = ttl_df['Mile']
# # y = range(20)
# # x1 = range(20)
# # x2 = range(0, 200, 10)
 

fig, axes = plt.subplots(ncols=2, sharey=True)
# plt.suptitle('中国市场各品牌的基本质保政策',fontproperties=zhfont2, fontsize=12)

axes[0].barh(y, x1, align='center', color='gray')
axes[0].set_xlabel('年限',fontproperties=zhfont1)
axes[0].invert_xaxis()
axes[0].set_yticks([])
axes[0].spines['top'].set_visible(False)  
axes[0].spines['right'].set_visible(False)
# axes[0].spines['bottom'].set_visible(False)  
axes[0].spines['left'].set_visible(False)  


axes[1].barh(y, x2, align='center', color='gray')
axes[1].set_xlabel('里程(公里)',fontproperties=zhfont1)
axes[1].spines['top'].set_visible(False)  
axes[1].spines['right'].set_visible(False)
# axes[1].spines['bottom'].set_visible(False)  
axes[1].spines['left'].set_visible(False) 

# axes[0].set_yticklabels(ylab,fontsize=8,ha='center')
# axes[0].yaxis.tick_right()

# for ax in axes.flat:
    # ax.margins(0.03)
    # ax.grid(True)

fig.tight_layout(rect=[0, 0.05, 1, 0.95])
fig.subplots_adjust(wspace=0.5)

for y, text in zip(range(len(ylab)),
                         [x  for x in list(ylab)]):
    plt.text(-40000, y-0.3, text,ha='center',fontproperties=zhfont1)   ##-19000,-19000,-19000,-10000  

plt.figtext(0.05, 0.0, '数据来源：论文作者根据各品牌官方网站数据整理', ha='left', va = 'bottom',fontproperties=zhfont1,size=10) 
# fig.set_tight_layout(True)
fig.savefig('C:/Private/Analysis/python/mine/paper/CHNbrandpolicy' + nameL +'.png')  
plt.show()