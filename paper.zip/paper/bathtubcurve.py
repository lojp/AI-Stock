# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
import matplotlib.pyplot as plt 
import numpy as np
import matplotlib
zhfont1 = matplotlib.font_manager.FontProperties(fname='C:\\Windows\\Fonts\\simsun.ttc')
zhfont2 = matplotlib.font_manager.FontProperties(fname='C:\\Private\\Analysis\\python\\Fonts\\MSYH.TTC')


def cure_data(x):
    one = x**4 - x - 1
    two = -10*x + 250
    three = x**3 -4*(x**2) + 8*x +1.5
    return np.maximum(one, two,three)

x=np.arange(-7,6.6,0.05)
y=cure_data(x)




fig = plt.figure()
ax = fig.add_subplot(111)

plt.plot(x,y,'b--')
plt.xticks([])
plt.yticks([])
plt.plot([-4.1, -4.1], [400, 2000], 'k--', lw=1)
plt.plot([3.7, 3.7], [300, 2000], 'k--', lw=1)

plt.text(-6, 1700, r'早期故障期',horizontalalignment='center',fontproperties=zhfont1)
plt.text(0, 1700, r'偶然故障期',horizontalalignment='center',fontproperties=zhfont1)
plt.text(5, 1700, r'耗损失效期',horizontalalignment='center',fontproperties=zhfont1)

# plt.xlabel('Time')
plt.ylabel('失效率',fontproperties=zhfont1)
plt.title('可靠性分析：浴盆曲线',fontproperties=zhfont2, fontsize=12)

for side in ['bottom','right','top','left']:
    ax.spines[side].set_visible(False)

ax.xaxis.set_ticks_position('none') # tick markers
ax.yaxis.set_ticks_position('none')

label = ax.set_xlabel('时间',fontproperties=zhfont1)
ax.xaxis.set_label_coords(0.5, -0.05)

xmin, xmax = ax.get_xlim() 
ymin, ymax = ax.get_ylim()
ax.xaxis.set_ticks_position('none') # tick markers
ax.yaxis.set_ticks_position('none')


ax.annotate("",xy=(-7.5, 1600), xycoords='data',
            xytext=(-4.5, 1600), textcoords='data',
            arrowprops=dict(arrowstyle="<->",
                            connectionstyle="arc3"),
            )

ax.annotate("",xy=(-3.5, 1600), xycoords='data',
            xytext=(3.5, 1600), textcoords='data',
            arrowprops=dict(arrowstyle="<->",
                            connectionstyle="arc3"),
            )           

ax.annotate("",xy=(4.1, 1600), xycoords='data',
            xytext=(6.2, 1600), textcoords='data',
            arrowprops=dict(arrowstyle="<->",
                            connectionstyle="arc3"),
            )           
dps = fig.dpi_scale_trans.inverted()
bbox = ax.get_window_extent().transformed(dps)
width, height = bbox.width, bbox.height

hw = 1./40.*(ymax-ymin) 
hl = 1./40.*(xmax-xmin)
lw = 1. # axis line width
ohg = 0.3 # arrow overhang
 
# compute matching arrowhead length and width
yhw = hw/(ymax-ymin)*(xmax-xmin)* height/width 
yhl = hl/(xmax-xmin)*(ymax-ymin)* width/height
 
# draw x and y axis
ax.arrow(xmin-0.2, 0, xmax-xmin, 0, fc='k', ec='k', lw = lw, 
         head_width=hw, head_length=hl, overhang = ohg, 
         length_includes_head= True, clip_on = False) 
 
ax.arrow(-7.85, ymin-90, 0, ymax-ymin, fc='k', ec='k', lw = lw, 
         head_width=yhw, head_length=yhl, overhang = ohg, 
         length_includes_head= True, clip_on = False) 

fig.savefig('C:/Private/Analysis/python/mine/paper/Bathtubcurve.png')          
plt.show()