# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 09:37:17 2017
@author: lojp
"""
from scipy import stats 
from scipy.optimize import curve_fit 
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import asarray as ar,exp
import math
from sklearn import metrics

ydata = [0.0041999999999999997, 0.0099869999999999994, 0.015879000000000001, 
    0.021288000000000001, 0.027421000000000001, 0.035160999999999998, 
    0.041052999999999999, 0.049036000000000003, 0.057980999999999998, 
    0.066203999999999999, 0.072849999999999998, 0.079033000000000006, 
    0.083266999999999994, 0.086085999999999996, 0.0929999999999997]

df = pd.read_excel('C:/Private/Analysis/python/mine/R1000/test.xlsx', sheet_name='Sheet1')

x = df['TIS']

a = df['R1000_x']/1000
fa = df['Forecast_R1000_x']/1000

b = df['R1000_y']/1000
fb = df['Forecast_R1000_y']/1000

# D_kl = metrics.mutual_info_score(fa,fb)
# print(D_kl)

fig = plt.figure(figsize=(8,6))
ax=fig.add_subplot(111)
ax.set_xlim(xmin=0.0, xmax=36)
ax.set_ylim([0,0.4])
plt.step(x,a,'b-',where='mid',label='D7_9155 Actual')
plt.step(x,b,'g-',where='mid',label='KR_08215 Actual')
plt.plot(x,fa,'r--',label='D7_9155 Forecast')
plt.plot(x,fb,'k--',label='KR_08215 Forecast')
plt.ylabel("Cumulative density")
plt.xlabel("TIS")
plt.title('CDF Distribution')
plt.legend()
plt.show()